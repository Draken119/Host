// ============================================================
//  vendas.js — Sistema de Vendas de Planos VPS / Hospedagem
//
//  Usa mongodb nativo (mesmo driver do resto do projeto).
//  Inicializado via vendas.init(botClient, mpPaymentClient)
//  após a conexão MongoDB estar pronta.
// ============================================================

'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  SlashCommandBuilder,
} = require('discord.js');

// ─────────────────────────────────────────────────────────
//  ⚙️  CONFIGURAÇÕES — edite aqui
// ─────────────────────────────────────────────────────────

/** IDs dos administradores que podem usar /admin_vendas */
const ADMIN_IDS_VENDAS = (process.env.ADMIN_IDS || '').split(',').filter(Boolean);

/** Canal de log de vendas (ID) */
const CANAL_VENDAS_LOG_ID = process.env.VENDAS_LOG_CHANNEL || '';

/** ID do servidor principal */
const SERVIDOR_ID = process.env.GUILD_ID || '';

/** Banner dos embeds */
const BANNER_URL = process.env.BANNER_URL ||
  'https://media.discordapp.net/attachments/1429997129388134500/1471283833583173776/Banner_Fm.png?format=webp&quality=lossless';

/**
 * Cargo Discord atribuído ao comprar qualquer plano.
 * Troque pelo ID real do cargo de cliente.
 */
const CARGO_CLIENTE_ID = process.env.CARGO_CLIENTE_ID || '';

// ─────────────────────────────────────────────────────────
//  📦  PLANOS — edite valores, nomes e limites
// ─────────────────────────────────────────────────────────

const PLANOS_VPS = {
  starter: {
    nome:      'Starter',
    emoji:     '🚀',
    valor:     9.90,
    dias:      30,
    maxBots:   1,
    ram:       '256 MB',
    descricao: '**Perfeito para começar.** Ideal para quem tem apenas 1 bot.',
    destaques: ['1 bot hospedado', '256 MB de RAM', 'Suporte por ticket', 'Uptime 24/7'],
  },
  basico: {
    nome:      'Básico',
    emoji:     '⚡',
    valor:     19.90,
    dias:      30,
    maxBots:   3,
    ram:       '512 MB',
    descricao: '**Mais espaço, mais bots.** Ótimo para projetos em crescimento.',
    destaques: ['Até 3 bots hospedados', '512 MB de RAM', 'Suporte prioritário', 'Reinício automático'],
  },
  pro: {
    nome:      'Pro',
    emoji:     '🔥',
    valor:     39.90,
    dias:      30,
    maxBots:   7,
    ram:       '1 GB',
    descricao: '**O favorito dos devs.** Alta performance para múltiplos bots.',
    destaques: ['Até 7 bots hospedados', '1 GB de RAM', 'Suporte VIP', 'Logs em tempo real', 'Backups diários'],
  },
  premium: {
    nome:      'Premium',
    emoji:     '💎',
    valor:     59.90,
    dias:      30,
    maxBots:   15,
    ram:       '2 GB',
    descricao: '**Máximo poder.** Para quem precisa de escala e confiabilidade.',
    destaques: ['Até 15 bots hospedados', '2 GB de RAM', 'Suporte 24h', 'Backups diários', 'IP dedicado'],
  },
  ultimate: {
    nome:      'Ultimate',
    emoji:     '👑',
    valor:     89.90,
    dias:      30,
    maxBots:   null, // ilimitado
    ram:       '4 GB',
    descricao: '**Sem limites.** Hospede quantos bots quiser com total liberdade.',
    destaques: ['Bots ILIMITADOS', '4 GB de RAM', 'Suporte dedicado', 'Backups em tempo real', 'IP dedicado'],
  },
};

// ─────────────────────────────────────────────────────────
//  Estado interno
// ─────────────────────────────────────────────────────────

let _bot       = null;
let _mp        = null;
let _db        = null; // instância mongodb nativa

/**
 * Inicializa o módulo.
 * @param {import('discord.js').Client} botClient
 * @param {object} mpPaymentClient — instância de Payment do mercadopago
 * @param {import('mongodb').Db} mongoDb — db mongodb nativo já conectado
 */
function init(botClient, mpPaymentClient, mongoDb) {
  _bot = botClient;
  _mp  = mpPaymentClient;
  _db  = mongoDb;

  // Garantir índices únicos
  _db.collection('vendas_vps').createIndex({ payment_id: 1 }, { unique: true }).catch(() => {});
  _db.collection('cupons_vps').createIndex({ codigo: 1 },     { unique: true }).catch(() => {});

  console.log('✅ [vendas.js] Módulo de vendas VPS inicializado.');
}

// ─────────────────────────────────────────────────────────
//  Helpers de coleção
// ─────────────────────────────────────────────────────────

function colVendas()  { return _db.collection('vendas_vps');  }
function colCupons()  { return _db.collection('cupons_vps');  }

function isAdminVendas(userId) {
  return ADMIN_IDS_VENDAS.includes(userId);
}

function fmt(v) { return `R$${v.toFixed(2).replace('.', ',')}`; }

function calcFinal(plano, desc) {
  const base = PLANOS_VPS[plano].valor;
  if (!desc) return base;
  return parseFloat((base * (1 - desc / 100)).toFixed(2));
}

// ─────────────────────────────────────────────────────────
//  MercadoPago
// ─────────────────────────────────────────────────────────

async function criarPix(plano, userId, username, valorFinal) {
  const idempotency = `vps_${userId}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const r = await _mp.create({
    body: {
      transaction_amount: valorFinal,
      description:        `VPS Host — Plano ${PLANOS_VPS[plano].nome}`,
      payment_method_id:  'pix',
      payer: { email: `vps_${userId}@hostbot.app`, first_name: username, last_name: 'Discord' },
    },
    requestOptions: { idempotencyKey: idempotency },
  });
  return {
    id:           r.id,
    qrCode:       r.point_of_interaction?.transaction_data?.qr_code,
    qrCodeBase64: r.point_of_interaction?.transaction_data?.qr_code_base64,
  };
}

async function checkPagamento(paymentId) {
  try {
    const r = await _mp.get({ id: paymentId });
    return { status: r.status, aprovado: r.status === 'approved', rejeitado: ['rejected', 'cancelled', 'refunded'].includes(r.status) };
  } catch {
    return { status: 'error', aprovado: false, rejeitado: false };
  }
}

// ─────────────────────────────────────────────────────────
//  Monitoramento de pagamento
// ─────────────────────────────────────────────────────────

function monitorar(paymentId, vendaId) {
  let tentativas = 0;
  const max = 60; // 30 min
  const interval = setInterval(async () => {
    tentativas++;
    try {
      const res = await checkPagamento(paymentId);
      if (res.aprovado) {
        clearInterval(interval);
        const venda = await colVendas().findOne({ _id: vendaId });
        if (venda && venda.status === 'pending') await processarAprovacao(venda);
      } else if (res.rejeitado) {
        clearInterval(interval);
        await colVendas().updateOne({ _id: vendaId }, { $set: { status: 'rejected' } });
      } else if (tentativas >= max) {
        clearInterval(interval);
      }
    } catch (e) { console.error('[vendas] Erro monitoramento:', e.message); }
  }, 30_000);
}

// ─────────────────────────────────────────────────────────
//  Pós-aprovação
// ─────────────────────────────────────────────────────────

async function processarAprovacao(venda) {
  try {
    const expiraEm = Date.now() + PLANOS_VPS[venda.plano].dias * 86400000;
    await colVendas().updateOne({ _id: venda._id }, {
      $set: { status: 'approved', aprovado_em: Date.now(), expira_em: expiraEm },
    });

    const p = PLANOS_VPS[venda.plano];

    // Cargo
    try {
      const guild  = _bot.guilds.cache.get(SERVIDOR_ID);
      const member = guild ? await guild.members.fetch(venda.user_id).catch(() => null) : null;
      if (member && CARGO_CLIENTE_ID && !member.roles.cache.has(CARGO_CLIENTE_ID)) {
        await member.roles.add(CARGO_CLIENTE_ID);
      }
    } catch { /* silencia */ }

    // DM comprador
    try {
      const user = await _bot.users.fetch(venda.user_id).catch(() => null);
      if (user) {
        const embed = new EmbedBuilder()
          .setTitle(`${p.emoji} Pagamento Aprovado — Plano ${p.nome}!`)
          .setDescription(
            `**Plano:** ${p.emoji} ${p.nome}\n` +
            `**Bots:** ${p.maxBots ?? '∞ Ilimitado'} | **RAM:** ${p.ram}\n` +
            `**Valor pago:** ${fmt(venda.valor)}\n` +
            `**Expira em:** \`${new Date(expiraEm).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}\`\n\n` +
            `🎉 Use \`/status_vps\` para ver seu plano!`
          )
          .setColor(0xFAA300)
          .setImage(BANNER_URL)
          .setTimestamp();
        await user.send({ embeds: [embed] }).catch(() => {});
      }
    } catch { /* DM fechada */ }

    // Log canal
    try {
      if (CANAL_VENDAS_LOG_ID) {
        const canal = await _bot.channels.fetch(CANAL_VENDAS_LOG_ID).catch(() => null);
        if (canal?.isTextBased()) {
          const logEmbed = new EmbedBuilder()
            .setTitle('🎉 Nova Venda VPS!')
            .setColor(0xFAA300)
            .addFields(
              { name: '👤 Cliente',  value: `<@${venda.user_id}>\n\`${venda.user_id}\``,                                              inline: true },
              { name: '📦 Plano',    value: `${p.emoji} **${p.nome}**\n${p.maxBots ?? '∞'} bots · ${p.ram}`,                         inline: true },
              { name: '💰 Valor',    value: venda.desconto_apl > 0
                  ? `~~${fmt(PLANOS_VPS[venda.plano].valor)}~~ **${fmt(venda.valor)}** 🎟️ \`${venda.cupom}\``
                  : `**${fmt(venda.valor)}**`,                                                                                         inline: true },
              { name: '📅 Expira',   value: new Date(expiraEm).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }), inline: false },
            )
            .setImage(BANNER_URL)
            .setTimestamp();
          await canal.send({ content: `🎉 <@${venda.user_id}>`, embeds: [logEmbed] });
        }
      }
    } catch { /* silencia */ }

    console.log(`✅ [vendas] Venda aprovada: ${venda.user_id} → ${venda.plano}`);
  } catch (e) {
    console.error('❌ [vendas] processarAprovacao:', e);
  }
}

// ─────────────────────────────────────────────────────────
//  Embeds
// ─────────────────────────────────────────────────────────

function embedVitrine() {
  const linhas = Object.entries(PLANOS_VPS).map(([, p]) => {
    const bots = p.maxBots ? `${p.maxBots} bot${p.maxBots > 1 ? 's' : ''}` : '∞ ilimitado';
    return `> ${p.emoji} **${p.nome}** — ${fmt(p.valor)}/mês · ${bots} · ${p.ram} RAM`;
  });
  return new EmbedBuilder()
    .setDescription(
      `# 🖥️ Hospedagem VPS para Bots Discord\n` +
      `Mantenha seu bot **online 24/7** com infraestrutura profissional!\n\n` +
      `### 💳 Planos Disponíveis\n` +
      linhas.join('\n') +
      `\n\n✅ Pagamento via **PIX** com aprovação automática.`
    )
    .setColor(0xFAA300)
    .setImage(BANNER_URL)
    .setFooter({ text: 'Aprovação em segundos · PIX automático' });
}

function embedPlano(plano) {
  const p = PLANOS_VPS[plano];
  return new EmbedBuilder()
    .setTitle(`${p.emoji} Plano ${p.nome} — ${fmt(p.valor)}/mês`)
    .setDescription(p.descricao + '\n\n**Inclui:**\n' + p.destaques.map(d => `✅ ${d}`).join('\n'))
    .setColor(0xFAA300)
    .setImage(BANNER_URL)
    .setFooter({ text: 'Pagamento via PIX' });
}

// ─────────────────────────────────────────────────────────
//  Gerador de PIX
// ─────────────────────────────────────────────────────────

async function gerarPix(interaction, plano, descPercent, codigoCupom) {
  const { user } = interaction;
  const valorFinal = calcFinal(plano, descPercent);
  const p          = PLANOS_VPS[plano];

  try {
    const pag = await criarPix(plano, user.id, user.username, valorFinal);

    const novaVenda = {
      user_id:      user.id,
      username:     user.username,
      plano,
      valor:        valorFinal,
      payment_id:   String(pag.id),
      cupom:        codigoCupom || null,
      desconto_apl: descPercent || 0,
      status:       'pending',
      criado_em:    Date.now(),
      aprovado_em:  null,
      expira_em:    null,
    };

    const res    = await colVendas().insertOne(novaVenda);
    const qrBuf  = pag.qrCodeBase64 ? Buffer.from(pag.qrCodeBase64, 'base64') : null;

    const embed = new EmbedBuilder()
      .setTitle(`💳 PIX Gerado — Plano ${p.nome}`)
      .setColor(0xFAA300)
      .setFooter({ text: 'Aprovação automática após pagamento' })
      .setTimestamp();

    let desc = `**Plano:** ${p.emoji} ${p.nome} · ${p.maxBots ?? '∞'} bots · ${p.ram}\n**Duração:** 30 dias\n`;
    if (descPercent > 0) {
      desc += `**Valor:** ~~${fmt(PLANOS_VPS[plano].valor)}~~ **${fmt(valorFinal)}** — ${descPercent}% off 🎟️ \`${codigoCupom}\`\n`;
    } else {
      desc += `**Valor:** **${fmt(valorFinal)}**\n`;
    }
    desc += `\n**PIX Copia e Cola:**`;
    embed.setDescription(desc);
    embed.addFields({ name: '\u200B', value: `\`\`\`\n${pag.qrCode}\n\`\`\`` });
    if (qrBuf) embed.setImage('attachment://qrcode.png');

    const msg = { embeds: [embed] };
    if (qrBuf) msg.files = [{ attachment: qrBuf, name: 'qrcode.png' }];
    await interaction.editReply(msg);

    monitorar(pag.id, res.insertedId);
  } catch (e) {
    console.error('[vendas] Erro gerarPix:', e);
    await interaction.editReply({ content: `❌ Erro ao gerar PIX: \`${e.message}\`` });
  }
}

// ─────────────────────────────────────────────────────────
//  Slash commands exportados
// ─────────────────────────────────────────────────────────

const slashCommands = [
  new SlashCommandBuilder().setName('comprar').setDescription('🛒 Comprar ou renovar um plano VPS'),
  new SlashCommandBuilder().setName('status_vps').setDescription('📊 Ver seu plano VPS ativo'),
  new SlashCommandBuilder().setName('admin_vendas').setDescription('👑 Painel admin de vendas (apenas admins)'),
];

// ─────────────────────────────────────────────────────────
//  Roteador central — retorna true se tratou a interaction
// ─────────────────────────────────────────────────────────

async function handleInteraction(interaction) {
  try {

    // ── Slash Commands ──────────────────────────────────
    if (interaction.isChatInputCommand()) {

      if (interaction.commandName === 'comprar') {
        const select = new StringSelectMenuBuilder()
          .setCustomId('vps_select_plano')
          .setPlaceholder('Escolha seu plano')
          .addOptions(Object.entries(PLANOS_VPS).map(([key, p]) => ({
            label:       `${p.nome} — ${fmt(p.valor)}/mês`,
            description: `${p.maxBots ? `Até ${p.maxBots} bot${p.maxBots > 1 ? 's' : ''}` : 'Ilimitado'} · ${p.ram}`,
            value:       key,
            emoji:       p.emoji,
          })));
        await interaction.reply({
          embeds:     [embedVitrine()],
          components: [new ActionRowBuilder().addComponents(select)],
          ephemeral:  true,
        });
        return true;
      }

      if (interaction.commandName === 'status_vps') {
        const agora = Date.now();
        const venda = await colVendas().findOne({
          user_id:   interaction.user.id,
          status:    'approved',
          expira_em: { $gt: agora },
        }, { sort: { expira_em: -1 } });

        if (!venda) {
          return interaction.reply({ content: '❌ Você não tem plano VPS ativo.\nUse `/comprar` para adquirir!', ephemeral: true }), true;
        }

        const p        = PLANOS_VPS[venda.plano] || {};
        const diasRest = Math.ceil((venda.expira_em - agora) / 86400000);
        const embed = new EmbedBuilder()
          .setTitle(`${p.emoji || '📦'} Seu Plano VPS Ativo`)
          .setColor(diasRest <= 7 ? 0xFEE75C : 0xFAA300)
          .addFields(
            { name: '📦 Plano',          value: `**${p.nome}**`,                        inline: true },
            { name: '🤖 Bots',           value: `**${p.maxBots ?? '∞'}**`,              inline: true },
            { name: '💾 RAM',            value: `**${p.ram}**`,                          inline: true },
            { name: '⏳ Dias Restantes', value: `**${diasRest}** dia(s)`,               inline: true },
            { name: '📅 Expira em',      value: new Date(venda.expira_em).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }), inline: true },
          )
          .setImage(BANNER_URL)
          .setTimestamp();
        if (diasRest <= 7) embed.addFields({ name: '⚠️ Aviso', value: 'Plano próximo do vencimento! Use `/comprar` para renovar.', inline: false });
        await interaction.reply({ embeds: [embed], ephemeral: true });
        return true;
      }

      if (interaction.commandName === 'admin_vendas') {
        if (!isAdminVendas(interaction.user.id)) {
          return interaction.reply({ content: '❌ Sem permissão!', ephemeral: true }), true;
        }
        const total     = await colVendas().countDocuments();
        const aprovadas = await colVendas().countDocuments({ status: 'approved' });
        const pendentes = await colVendas().countDocuments({ status: 'pending' });
        const receitaAgg = await colVendas().aggregate([
          { $match: { status: 'approved' } },
          { $group: { _id: null, total: { $sum: '$valor' } } },
        ]).toArray();
        const receita = receitaAgg[0]?.total || 0;
        const cupons  = await colCupons().countDocuments({ ativo: true });

        const embed = new EmbedBuilder()
          .setTitle('👑 Admin — Vendas VPS')
          .setColor(0xFAA300)
          .addFields(
            { name: '📊 Total',     value: total.toString(),     inline: true },
            { name: '✅ Aprovadas', value: aprovadas.toString(), inline: true },
            { name: '⏳ Pendentes', value: pendentes.toString(), inline: true },
            { name: '💰 Receita',   value: fmt(receita),          inline: true },
            { name: '🎟️ Cupons',   value: cupons.toString(),     inline: true },
          )
          .setTimestamp();
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('vps_admin_cupons').setLabel('Cupons').setStyle(ButtonStyle.Primary).setEmoji('🎟️'),
          new ButtonBuilder().setCustomId('vps_admin_recentes').setLabel('Vendas Recentes').setStyle(ButtonStyle.Secondary).setEmoji('📋'),
          new ButtonBuilder().setCustomId('vps_admin_dar_plano').setLabel('Dar Plano').setStyle(ButtonStyle.Success).setEmoji('🎁'),
        );
        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
        return true;
      }
    }

    // ── Select Menus ────────────────────────────────────
    if (interaction.isStringSelectMenu()) {

      if (interaction.customId === 'vps_select_plano') {
        const plano = interaction.values[0];
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`vps_usar_cupom_${plano}`).setLabel('Tenho cupom').setStyle(ButtonStyle.Secondary).setEmoji('🎟️'),
          new ButtonBuilder().setCustomId(`vps_sem_cupom_${plano}`).setLabel('Comprar agora').setStyle(ButtonStyle.Success).setEmoji('💳'),
        );
        await interaction.reply({ embeds: [embedPlano(plano)], components: [row], ephemeral: true });
        return true;
      }

      if (interaction.customId === 'vps_admin_del_cupom_select') {
        if (!isAdminVendas(interaction.user.id)) return true;
        const codigo = interaction.values[0];
        await colCupons().deleteOne({ codigo });
        await interaction.update({ content: `✅ Cupom **${codigo}** removido!`, embeds: [], components: [] });
        return true;
      }
    }

    // ── Botões ──────────────────────────────────────────
    if (interaction.isButton()) {

      if (interaction.customId.startsWith('vps_usar_cupom_')) {
        const plano = interaction.customId.replace('vps_usar_cupom_', '');
        const modal = new ModalBuilder().setCustomId(`vps_modal_cupom_${plano}`).setTitle('Inserir Cupom de Desconto');
        modal.addComponents(new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('codigo_cupom').setLabel('Código do Cupom').setStyle(TextInputStyle.Short).setPlaceholder('Ex: DESCONTO10').setRequired(true)
        ));
        await interaction.showModal(modal);
        return true;
      }

      if (interaction.customId.startsWith('vps_sem_cupom_')) {
        const plano = interaction.customId.replace('vps_sem_cupom_', '');
        await interaction.deferReply({ ephemeral: true });
        await gerarPix(interaction, plano, 0, null);
        return true;
      }

      if (interaction.customId === 'vps_admin_cupons') {
        if (!isAdminVendas(interaction.user.id)) return true;
        const cupons = await colCupons().find({ ativo: true }).toArray();
        const embed = new EmbedBuilder()
          .setTitle('🎟️ Cupons VPS Ativos').setColor(0xFAA300)
          .setDescription(cupons.length === 0
            ? 'Nenhum cupom ativo.'
            : cupons.map(c => `**${c.codigo}** — ${c.desconto}% | ${c.usos}/${c.max_usos ?? '∞'} usos${c.planos?.length ? ` | ${c.planos.join(', ')}` : ' | todos'}`).join('\n'));
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('vps_admin_criar_cupom').setLabel('Criar Cupom').setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId('vps_admin_del_cupom').setLabel('Deletar Cupom').setStyle(ButtonStyle.Danger).setDisabled(!cupons.length),
          new ButtonBuilder().setCustomId('vps_admin_voltar').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
        );
        await interaction.update({ embeds: [embed], components: [row] });
        return true;
      }

      if (interaction.customId === 'vps_admin_criar_cupom') {
        if (!isAdminVendas(interaction.user.id)) return true;
        const modal = new ModalBuilder().setCustomId('vps_modal_criar_cupom').setTitle('Criar Cupom VPS');
        modal.addComponents(
          new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('codigo').setLabel('Código').setStyle(TextInputStyle.Short).setPlaceholder('Ex: VPS20').setRequired(true)),
          new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('desconto').setLabel('Desconto (%)').setStyle(TextInputStyle.Short).setPlaceholder('Ex: 20').setRequired(true)),
          new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('max_usos').setLabel('Máx. usos (0 = ilimitado)').setStyle(TextInputStyle.Short).setPlaceholder('Ex: 50').setRequired(true)),
          new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('planos').setLabel('Planos válidos (vazio = todos)').setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder('Ex: starter,pro')),
        );
        await interaction.showModal(modal);
        return true;
      }

      if (interaction.customId === 'vps_admin_del_cupom') {
        if (!isAdminVendas(interaction.user.id)) return true;
        const cupons = await colCupons().find({ ativo: true }).toArray();
        if (!cupons.length) { await interaction.reply({ content: '❌ Nenhum cupom!', ephemeral: true }); return true; }
        const select = new StringSelectMenuBuilder()
          .setCustomId('vps_admin_del_cupom_select')
          .setPlaceholder('Selecione o cupom')
          .addOptions(cupons.map(c => ({ label: `${c.codigo} — ${c.desconto}%`, value: c.codigo })));
        await interaction.reply({ content: '🗑️ Selecione:', components: [new ActionRowBuilder().addComponents(select)], ephemeral: true });
        return true;
      }

      if (interaction.customId === 'vps_admin_recentes') {
        if (!isAdminVendas(interaction.user.id)) return true;
        const recentes = await colVendas().find({ status: 'approved' }).sort({ aprovado_em: -1 }).limit(10).toArray();
        const embed = new EmbedBuilder().setTitle('📋 Últimas Vendas VPS').setColor(0xFAA300)
          .setDescription(recentes.length === 0
            ? 'Nenhuma venda ainda.'
            : recentes.map(v => {
                const p    = PLANOS_VPS[v.plano] || {};
                const data = v.aprovado_em ? new Date(v.aprovado_em).toLocaleDateString('pt-BR') : '?';
                return `• <@${v.user_id}> → ${p.emoji || ''} **${p.nome || v.plano}** — ${fmt(v.valor)} em ${data}`;
              }).join('\n'))
          .setTimestamp();
        await interaction.reply({ embeds: [embed], ephemeral: true });
        return true;
      }

      if (interaction.customId === 'vps_admin_dar_plano') {
        if (!isAdminVendas(interaction.user.id)) return true;
        const modal = new ModalBuilder().setCustomId('vps_modal_dar_plano').setTitle('Dar Plano VPS Manual');
        modal.addComponents(
          new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('user_id').setLabel('ID do usuário Discord').setStyle(TextInputStyle.Short).setRequired(true)),
          new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('plano_key').setLabel('Plano (starter/basico/pro/premium/ultimate)').setStyle(TextInputStyle.Short).setRequired(true)),
          new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('dias').setLabel('Dias de acesso').setStyle(TextInputStyle.Short).setPlaceholder('Ex: 30').setRequired(true)),
        );
        await interaction.showModal(modal);
        return true;
      }

      if (interaction.customId === 'vps_admin_voltar') {
        if (!isAdminVendas(interaction.user.id)) return true;
        // Fecha sem reabrir — apenas volta
        await interaction.update({ content: '↩️ Painel fechado.', embeds: [], components: [] });
        return true;
      }
    }

    // ── Modais ──────────────────────────────────────────
    if (interaction.isModalSubmit()) {

      if (interaction.customId.startsWith('vps_modal_cupom_')) {
        const plano  = interaction.customId.replace('vps_modal_cupom_', '');
        const codigo = interaction.fields.getTextInputValue('codigo_cupom').trim().toUpperCase();
        const cupom  = await colCupons().findOne({ codigo, ativo: true });

        if (!cupom)                                        return interaction.reply({ content: '❌ Cupom inválido ou expirado!', ephemeral: true }), true;
        if (cupom.max_usos !== null && cupom.usos >= cupom.max_usos) return interaction.reply({ content: '❌ Cupom sem usos restantes!', ephemeral: true }), true;
        if (cupom.planos?.length && !cupom.planos.includes(plano))   return interaction.reply({ content: `❌ Cupom inválido para este plano!`, ephemeral: true }), true;

        await colCupons().updateOne({ codigo }, { $inc: { usos: 1 } });
        await interaction.deferReply({ ephemeral: true });
        await gerarPix(interaction, plano, cupom.desconto, codigo);
        return true;
      }

      if (interaction.customId === 'vps_modal_criar_cupom') {
        if (!isAdminVendas(interaction.user.id)) return true;
        const codigo   = interaction.fields.getTextInputValue('codigo').trim().toUpperCase();
        const desconto = parseFloat(interaction.fields.getTextInputValue('desconto').trim());
        const maxUsos  = parseInt(interaction.fields.getTextInputValue('max_usos').trim());
        const planosRaw = (interaction.fields.getTextInputValue('planos') || '').trim();
        const planosArr = planosRaw ? planosRaw.split(',').map(s => s.trim().toLowerCase()).filter(Boolean) : [];

        if (isNaN(desconto) || desconto <= 0 || desconto >= 100) return interaction.reply({ content: '❌ Desconto inválido (1-99).', ephemeral: true }), true;
        const existe = await colCupons().findOne({ codigo });
        if (existe) return interaction.reply({ content: `❌ Cupom **${codigo}** já existe!`, ephemeral: true }), true;

        await colCupons().insertOne({
          codigo, desconto,
          max_usos:  isNaN(maxUsos) || maxUsos === 0 ? null : maxUsos,
          usos:      0,
          planos:    planosArr,
          ativo:     true,
          criado_por: interaction.user.id,
          criado_em:  Date.now(),
        });
        const txt = planosArr.length ? planosArr.join(', ') : 'todos os planos';
        await interaction.reply({ content: `✅ Cupom **${codigo}** criado!\n${desconto}% off · ${maxUsos === 0 ? 'ilimitado' : maxUsos + ' usos'} · ${txt}`, ephemeral: true });
        return true;
      }

      if (interaction.customId === 'vps_modal_dar_plano') {
        if (!isAdminVendas(interaction.user.id)) return true;
        const targetId = interaction.fields.getTextInputValue('user_id').trim();
        const planoKey = interaction.fields.getTextInputValue('plano_key').trim().toLowerCase();
        const dias     = parseInt(interaction.fields.getTextInputValue('dias').trim());

        if (!PLANOS_VPS[planoKey]) return interaction.reply({ content: `❌ Plano inválido! Use: ${Object.keys(PLANOS_VPS).join(', ')}`, ephemeral: true }), true;
        if (isNaN(dias) || dias < 1) return interaction.reply({ content: '❌ Dias inválidos!', ephemeral: true }), true;

        const expiraEm = Date.now() + dias * 86400000;
        await colVendas().insertOne({
          user_id: targetId, username: 'manual_admin', plano: planoKey,
          valor: 0, payment_id: `manual_${Date.now()}_${Math.random().toString(36).slice(2)}`,
          status: 'approved', cupom: null, desconto_apl: 0,
          criado_em: Date.now(), aprovado_em: Date.now(), expira_em: expiraEm,
        });

        try {
          const guild  = _bot.guilds.cache.get(SERVIDOR_ID);
          const member = guild ? await guild.members.fetch(targetId).catch(() => null) : null;
          if (member && CARGO_CLIENTE_ID) await member.roles.add(CARGO_CLIENTE_ID).catch(() => {});
        } catch { /* silencia */ }

        try {
          const user = await _bot.users.fetch(targetId).catch(() => null);
          if (user) {
            await user.send(
              `🎁 Você recebeu o **Plano ${PLANOS_VPS[planoKey].nome}** por ${dias} dias!\n` +
              `Expira em: \`${new Date(expiraEm).toLocaleDateString('pt-BR')}\`\nUse \`/status_vps\` para ver.`
            ).catch(() => {});
          }
        } catch { /* DM fechada */ }

        await interaction.reply({
          content: `✅ Plano **${PLANOS_VPS[planoKey].nome}** dado para <@${targetId}>! Expira: \`${new Date(expiraEm).toLocaleDateString('pt-BR')}\``,
          ephemeral: true,
        });
        return true;
      }
    }

    return false; // Não era deste módulo
  } catch (e) {
    console.error('[vendas] handleInteraction erro:', e);
    const msg = `❌ Erro: ${e.message}`;
    try {
      if (interaction.replied || interaction.deferred) await interaction.followUp({ content: msg, ephemeral: true });
      else await interaction.reply({ content: msg, ephemeral: true });
    } catch { /* silencia */ }
    return true;
  }
}

module.exports = { init, handleInteraction, slashCommands, PLANOS_VPS };

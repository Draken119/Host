// ============================================================
//  botManager.js — Utilitários de gerenciamento de arquivos
//  dos bots hospedados (pasta, .env, deps, etc.)
// ============================================================

'use strict';

const fs   = require('fs');
const fsp  = require('fs/promises');
const path = require('path');

// ─────────────────────────────────────────────────────────
//  sanitizeName — deixa apenas letras, números, - e _
// ─────────────────────────────────────────────────────────
function sanitizeName(name) {
  return name
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9\-_]/g, '')
    .slice(0, 40) || 'bot';
}

// ─────────────────────────────────────────────────────────
//  deleteFolder — remove pasta do bot recursivamente
// ─────────────────────────────────────────────────────────
async function deleteFolder(folderPath) {
  try {
    await fsp.rm(folderPath, { recursive: true, force: true });
  } catch (_) {}
}

// ─────────────────────────────────────────────────────────
//  stripRootFolder — se o zip foi criado comprimindo uma
//  pasta, move tudo um nível para cima
// ─────────────────────────────────────────────────────────
async function stripRootFolder(folderPath) {
  try {
    const entries = await fsp.readdir(folderPath);
    if (entries.length !== 1) return;

    const sub = path.join(folderPath, entries[0]);
    const stat = await fsp.stat(sub);
    if (!stat.isDirectory()) return;

    // Verificar se o arquivo host.config está dentro da subpasta
    const hasConfig = fs.existsSync(path.join(sub, 'host.config'));
    if (!hasConfig) return;

    // Mover tudo de sub para folderPath
    const subEntries = await fsp.readdir(sub);
    for (const entry of subEntries) {
      const src  = path.join(sub, entry);
      const dest = path.join(folderPath, entry);
      await fsp.rename(src, dest).catch(() => {});
    }
    await fsp.rm(sub, { recursive: true, force: true }).catch(() => {});
  } catch (_) {}
}

// ─────────────────────────────────────────────────────────
//  preSeedBotDirs — cria diretórios necessários no bot
// ─────────────────────────────────────────────────────────
async function preSeedBotDirs(folderPath) {
  const dirs = [
    path.join(folderPath, 'logs'),
    path.join(folderPath, 'data'),
  ];
  for (const dir of dirs) {
    await fsp.mkdir(dir, { recursive: true }).catch(() => {});
  }
}

// ─────────────────────────────────────────────────────────
//  createEnvFile — cria .env com o token do bot
// ─────────────────────────────────────────────────────────
async function createEnvFile(folderPath, token) {
  const envPath = path.join(folderPath, '.env');
  const content = `TOKEN=${token}\nDISCORD_TOKEN=${token}\n`;
  await fsp.writeFile(envPath, content, 'utf8');
}

// ─────────────────────────────────────────────────────────
//  detectRuntime — detecta Node.js ou Python pelo conteúdo
// ─────────────────────────────────────────────────────────
function detectRuntime(folderPath) {
  if (fs.existsSync(path.join(folderPath, 'package.json'))) return 'node';
  if (fs.existsSync(path.join(folderPath, 'requirements.txt'))) return 'python';
  return 'node';
}

// ─────────────────────────────────────────────────────────
//  installDependencies — instala deps do bot (legacy, sem Docker)
//  Usado apenas em modo não-Docker
// ─────────────────────────────────────────────────────────
async function installDependencies(folderPath, onProgress) {
  const { execFile } = require('child_process');
  const { promisify } = require('util');
  const execAsync = promisify(execFile);
  const warnings = [];

  const pkgJson = path.join(folderPath, 'package.json');
  if (fs.existsSync(pkgJson)) {
    await onProgress('📦 Instalando dependências Node.js...');
    try {
      await execAsync('npm', ['install', '--omit=dev', '--no-audit', '--no-fund'], {
        cwd: folderPath,
        timeout: 120_000,
      });
    } catch (e) {
      warnings.push(`npm install falhou: ${e.message}`);
    }
  }

  const reqTxt = path.join(folderPath, 'requirements.txt');
  if (fs.existsSync(reqTxt)) {
    await onProgress('🐍 Instalando dependências Python...');
    try {
      await execAsync('pip3', ['install', '-r', 'requirements.txt', '--break-system-packages'], {
        cwd: folderPath,
        timeout: 300_000,
      });
    } catch (e) {
      warnings.push(`pip install falhou: ${e.message}`);
    }
  }

  return { warnings };
}

module.exports = {
  sanitizeName,
  deleteFolder,
  stripRootFolder,
  preSeedBotDirs,
  createEnvFile,
  detectRuntime,
  installDependencies,
};

// ============================================================
//  processManager.js — Gerencia containers Docker dos bots
//
//  Cada bot roda em um container isolado com:
//   • Limite de RAM (config.DOCKER_MEMORY_LIMIT_MB)
//   • Sem acesso à rede do host (bridge isolada)
//   • Sem privilégios (no-new-privileges, cap-drop ALL)
//   • Sistema de arquivos read-only + tmpfs para /tmp
//   • Limite de PIDs (anti fork-bomb)
//   • Reinício automático em caso de crash
// ============================================================

const { execFile, execFileSync } = require('child_process');
const { promisify }  = require('util');
const { spawn }      = require('child_process');
const fs             = require('fs');
const fsp            = require('fs/promises');
const path           = require('path');
const execFileAsync  = promisify(execFile);
const config         = require('./config');
const { updateBot, getBotById } = require('./database/db');
const logger         = require('./utils/logger');
const lm             = require('./utils/logManager');

// ─────────────────────────────────────────────────────────
//  Estado interno
//  Map: botId => {
//    containerName, startedAt, restartCount, restartTimer,
//    folderPath, startCmd, autoRestart, logProcess, memoryMB
//  }
// ─────────────────────────────────────────────────────────
const activeContainers = new Map();

// Exportamos como activeProcesses para compatibilidade com index.js
const activeProcesses = activeContainers;

// ─────────────────────────────────────────────────────────
//  Helpers Docker
// ─────────────────────────────────────────────────────────
function containerName(botId) {
  return `hostbot_bot_${botId}`;
}

function docker(args, opts = {}) {
  return execFileAsync('docker', args, { timeout: 30_000, ...opts });
}

function dockerSync(args) {
  return execFileSync('docker', args, { timeout: 10_000, stdio: ['ignore', 'pipe', 'pipe'] })
    .toString()
    .trim();
}

// ─────────────────────────────────────────────────────────
//  DOCKERFILE_CONTENT — gerado inline para evitar dependência
//  de arquivo externo e garantir que sempre esteja correto.
//
//  Bug corrigido: --file externo ao contexto causava falha
//  no build. Agora o Dockerfile é escrito na pasta do bot
//  temporariamente e removido após o build.
// ─────────────────────────────────────────────────────────
function getDockerfileContent() {
  return `# Auto-gerado pelo Host Bot — não edite manualmente
FROM node:20-slim

# Instala Python 3 e dependências de build
RUN apt-get update && apt-get install -y --no-install-recommends \\
      python3 \\
      python3-pip \\
      python3-venv \\
      python3-dev \\
      build-essential \\
      ca-certificates \\
    && ln -sf /usr/bin/python3 /usr/bin/python \\
    && apt-get clean \\
    && rm -rf /var/lib/apt/lists/*

# Usuário sem privilégios (uid/gid 1001)
RUN groupadd -g 1001 bot && useradd -u 1001 -g bot -m -s /bin/sh bot

WORKDIR /app

# Copia arquivos do bot (contexto = pasta do bot)
COPY --chown=bot:bot . .

# Remove .env da imagem — será injetado em runtime via --env-file
RUN rm -f .env

# Instala dependências Node.js
RUN if [ -f "package.json" ]; then \\
      npm install --omit=dev --no-audit --no-fund --prefer-offline 2>&1; \\
    fi

# Instala dependências Python
# --break-system-packages necessário no Python 3.11+ (Debian 12+)
RUN if [ -f "requirements.txt" ]; then \\
      pip3 install --no-cache-dir --prefer-binary --break-system-packages -r requirements.txt 2>&1 || \\
      pip3 install --no-cache-dir --break-system-packages -r requirements.txt 2>&1; \\
    fi

USER bot
CMD ["node", "index.js"]
`;
}

// ─────────────────────────────────────────────────────────
//  buildImage — constrói imagem Docker com deps já instaladas
//  Escreve o Dockerfile na pasta do bot, faz o build,
//  e remove o Dockerfile temporário em seguida.
// ─────────────────────────────────────────────────────────
async function buildImage(botId, folderPath, onLog) {
  const tag            = `hostbot_bot_${botId}:latest`;
  const timeout        = Math.max(config.NPM_INSTALL_TIMEOUT_MS, config.PIP_INSTALL_TIMEOUT_MS) + 60_000;
  const dockerfilePath = path.join(folderPath, '_Dockerfile_hostbot');

  onLog?.('🐳 Construindo imagem Docker (instalando dependências)...');
  logger.info(`[PM] Buildando imagem ${tag}`);

  // Escreve Dockerfile temporário dentro do contexto de build
  await fsp.writeFile(dockerfilePath, getDockerfileContent(), 'utf8');

  try {
    const { stdout, stderr } = await execFileAsync(
      'docker',
      ['build', '--no-cache', '-t', tag, '-f', dockerfilePath, folderPath],
      { timeout, maxBuffer: 20 * 1024 * 1024 }
    );

    const buildOutput = (stdout + '\n' + stderr)
      .split('\n')
      .filter(l => l.trim())
      .slice(-20);

    for (const line of buildOutput) {
      lm.writeBotLog(botId, folderPath, '[BUILD] ' + line);
    }

    logger.ok(`[PM] Imagem ${tag} construída`);
    return tag;
  } catch (err) {
    const errMsg = (err.stderr || err.stdout || err.message || '').toString();
    lm.writeBotLog(botId, folderPath, '[BUILD ERROR] ' + errMsg);
    throw new Error(`Falha no build Docker:\n${errMsg.slice(0, 800)}`);
  } finally {
    // Remove Dockerfile temporário seja qual for o resultado
    fsp.unlink(dockerfilePath).catch(() => {});
  }
}

// ─────────────────────────────────────────────────────────
//  removeImage — remove imagem Docker de um bot
// ─────────────────────────────────────────────────────────
async function removeImage(botId) {
  const tag = `hostbot_bot_${botId}:latest`;
  try {
    await docker(['rmi', '-f', tag]);
    logger.info(`[PM] Imagem ${tag} removida`);
  } catch (_) {}
}

// ─────────────────────────────────────────────────────────
//  startContainer — executa o container isolado com limites
//  de segurança reforçados
// ─────────────────────────────────────────────────────────
async function startContainer(botId, folderPath, startCmd, memoryMB) {
  const name = containerName(botId);
  const tag  = `hostbot_bot_${botId}:latest`;
  const mem  = `${memoryMB ?? config.DOCKER_MEMORY_LIMIT_MB}m`;

  // Remove container anterior se existir
  try { await docker(['rm', '-f', name]); } catch (_) {}

  // Lê variáveis de ambiente do .env do bot
  const envPath = path.join(folderPath, '.env');
  const envArgs = fs.existsSync(envPath) ? ['--env-file', envPath] : [];

  const runArgs = [
    'run', '-d',
    '--name', name,

    // ── Limites de recursos ──────────────────────────────
    `--memory=${mem}`,
    `--memory-swap=${mem}`,       // desativa swap além da RAM permitida
    '--cpus=0.5',                 // máx 50% de 1 CPU por bot
    '--pids-limit=100',           // anti fork-bomb: máx 100 processos/threads

    // ── Segurança: sem privilégios ────────────────────────
    '--security-opt', 'no-new-privileges:true',
    '--cap-drop=ALL',             // remove todas as capabilities Linux
    '--user=1001:1001',           // força usuário não-root mesmo que CMD tente root

    // ── Rede isolada ─────────────────────────────────────
    '--network', config.DOCKER_NETWORK,

    // ── Volume: pasta do bot montada como bind mount ─────
    // O filesystem da imagem é read-only implicitamente (não se altera),
    // mas a pasta /app fica gravável para que o bot possa salvar dados.
    // O bot não tem acesso a nada fora de /app.
    '--volume', `${folderPath}:/app`,
    '--workdir', '/app',

    // ── Variáveis de ambiente do bot ──────────────────────
    ...envArgs,

    // ── Logs gerenciados pelo Docker ──────────────────────
    '--log-driver=json-file',
    '--log-opt', 'max-size=10m',
    '--log-opt', 'max-file=3',

    // Sem restart automático do Docker (gerenciamos via Node)
    '--restart=no',

    tag,
    ...startCmd.trim().split(/\s+/),
  ];

  await docker(runArgs);

  let shortId = name;
  try {
    shortId = dockerSync(['inspect', '--format={{.Id}}', name]).slice(0, 12);
  } catch (_) {}

  logger.ok(`[PM] Container ${name} iniciado (${shortId})`);
  return { name, shortId };
}

// ─────────────────────────────────────────────────────────
//  attachLogs — stream de logs do container → logManager
// ─────────────────────────────────────────────────────────
function attachLogs(botId, folderPath, name) {
  const logProc = spawn('docker', ['logs', '-f', '--tail=0', name], {
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  logProc.stdout.on('data', (data) => {
    lm.writeBotLog(botId, folderPath, data.toString());
  });

  logProc.stderr.on('data', (data) => {
    lm.writeBotLog(botId, folderPath, '[ERR] ' + data.toString());
  });

  logProc.on('error', (err) => {
    logger.warn(`[PM] Falha no log stream bot ${botId}: ${err.message}`);
  });

  return logProc;
}

// ─────────────────────────────────────────────────────────
//  watchContainer — monitora saída do container e faz restart
//
//  Bug corrigido: execFileAsync com timeout:0 causava timeout
//  imediato. Agora usamos spawn + evento 'close' para aguardar
//  o container indefinidamente sem timeout.
// ─────────────────────────────────────────────────────────
function watchContainer(botId, folderPath, startCmd, autoRestart, memoryMB) {
  const name = containerName(botId);

  return new Promise((resolve) => {
    // spawn 'docker wait' — bloqueia sem timeout até o container sair
    const waiter = spawn('docker', ['wait', name], {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    waiter.on('close', async (code) => {
      // Se foi parado pelo operador, a entrada já foi removida
      if (!activeContainers.has(botId)) return resolve();

      // Obtém exit code do container
      let exitCode = 1;
      try {
        exitCode = parseInt(dockerSync(['inspect', '--format={{.State.ExitCode}}', name])) || 0;
      } catch (_) {}

      const crashed = exitCode !== 0;
      lm.writeBotEvent(botId, folderPath, `Container encerrou — exitCode=${exitCode}`);
      logger.warn(`[PM] Bot ${botId} encerrou (exitCode=${exitCode})`);

      updateBot(botId, { status: crashed ? 'crashed' : 'stopped', pid: null });

      const entry = activeContainers.get(botId);
      if (entry?.logProcess) {
        try { entry.logProcess.kill(); } catch (_) {}
      }

      activeContainers.delete(botId);

      // Auto-restart
      if (autoRestart && crashed && entry && entry.restartCount < config.MAX_RESTART_ATTEMPTS) {
        entry.restartCount++;
        const msg = `Auto-restart ${entry.restartCount}/${config.MAX_RESTART_ATTEMPTS} em ${config.RESTART_DELAY_MS}ms...`;
        lm.writeBotEvent(botId, folderPath, msg);
        logger.info(`[PM] ${msg}`);

        // Mantém entry no map durante o delay
        activeContainers.set(botId, entry);

        entry.restartTimer = setTimeout(async () => {
          const botData = getBotById(botId);
          if (!botData) return;
          try {
            await startProcess(botId, folderPath, startCmd, autoRestart, memoryMB);
            if (activeContainers.has(botId)) {
              activeContainers.get(botId).restartCount = entry.restartCount;
            }
          } catch (err) {
            logger.error(`[PM] Falha no auto-restart de ${botId}: ${err.message}`);
            updateBot(botId, { status: 'crashed' });
            activeContainers.delete(botId);
          }
          resolve();
        }, config.RESTART_DELAY_MS);

      } else {
        if (autoRestart && crashed) {
          lm.writeBotEvent(botId, folderPath, `Máximo de restarts (${config.MAX_RESTART_ATTEMPTS}) atingido.`);
        }
        resolve();
      }
    });

    waiter.on('error', (err) => {
      logger.warn(`[PM] docker wait erro bot ${botId}: ${err.message}`);
      resolve();
    });
  });
}

// ─────────────────────────────────────────────────────────
//  startProcess — API pública
// ─────────────────────────────────────────────────────────
async function startProcess(botId, folderPath, startCmd, autoRestart = true, memoryMB) {
  if (activeContainers.has(botId)) {
    await killProcess(botId);
  }

  lm.initBot(botId);
  lm.writeBotEvent(botId, folderPath, `Iniciando container: ${startCmd}`);

  const { name, shortId } = await startContainer(botId, folderPath, startCmd, memoryMB);

  const entry = {
    containerName: name,
    startedAt:     new Date(),
    restartCount:  0,
    restartTimer:  null,
    botId,
    folderPath,
    startCmd,
    autoRestart,
    memoryMB:      memoryMB ?? config.DOCKER_MEMORY_LIMIT_MB,
    logProcess:    null,
  };

  activeContainers.set(botId, entry);
  entry.logProcess = attachLogs(botId, folderPath, name);

  // Monitora em background (sem await)
  watchContainer(botId, folderPath, startCmd, autoRestart, memoryMB).catch((err) => {
    logger.error(`[PM] watchContainer erro bot ${botId}: ${err.message}`);
  });

  updateBot(botId, {
    pid:        shortId,
    status:     'running',
    started_at: Math.floor(Date.now() / 1000),
  });

  lm.writeBotEvent(botId, folderPath, `Container iniciado: ${name} (${shortId})`);
  return shortId;
}

// ─────────────────────────────────────────────────────────
//  killProcess — para e remove o container
// ─────────────────────────────────────────────────────────
async function killProcess(botId) {
  const entry = activeContainers.get(botId);
  if (!entry) return false;

  if (entry.restartTimer) {
    clearTimeout(entry.restartTimer);
    entry.restartTimer = null;
  }

  entry.autoRestart = false;
  activeContainers.delete(botId); // Remove antes do stop para que watchContainer não faça restart

  const name = entry.containerName;
  lm.writeBotEvent(botId, entry.folderPath, 'Parando container (SIGTERM)...');

  if (entry.logProcess) {
    try { entry.logProcess.kill(); } catch (_) {}
  }

  try { await docker(['stop', '--time=10', name]); } catch (_) {}
  try { await docker(['rm', '-f', name]); } catch (_) {}

  return true;
}

// ─────────────────────────────────────────────────────────
//  getStats — estatísticas em tempo real via docker stats
// ─────────────────────────────────────────────────────────
function getStats(botId) {
  const entry = activeContainers.get(botId);
  if (!entry || entry.restartTimer) return null;

  const uptimeMs = Date.now() - entry.startedAt.getTime();
  let   memoryMB = null;

  try {
    const raw = dockerSync([
      'stats', '--no-stream',
      '--format', '{{.MemUsage}}',
      entry.containerName,
    ]);
    // Formato: "45.2MiB / 256MiB"
    const match = raw.match(/([\d.]+)\s*([KMG]i?B)/i);
    if (match) {
      const value = parseFloat(match[1]);
      const unit  = match[2].toUpperCase();
      if      (unit.startsWith('K')) memoryMB = (value / 1024).toFixed(1);
      else if (unit.startsWith('M')) memoryMB = value.toFixed(1);
      else if (unit.startsWith('G')) memoryMB = (value * 1024).toFixed(1);
    }
  } catch (_) {}

  return {
    pid:      entry.containerName,
    uptime:   formatUptime(uptimeMs),
    uptimeMs,
    memoryMB,
    restarts: entry.restartCount,
    status:   'running',
  };
}

// ─────────────────────────────────────────────────────────
//  isRunning
// ─────────────────────────────────────────────────────────
function isRunning(botId) {
  const entry = activeContainers.get(botId);
  return !!entry && !entry.restartTimer;
}

// ─────────────────────────────────────────────────────────
//  formatUptime
// ─────────────────────────────────────────────────────────
function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  if (d > 0) return `${d}d ${h % 24}h ${m % 60}m`;
  if (h > 0) return `${h}h ${m % 60}m ${s % 60}s`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

module.exports = {
  startProcess,
  killProcess,
  getStats,
  isRunning,
  buildImage,
  removeImage,
  activeContainers,
  activeProcesses, // alias para compatibilidade com index.js
};

//
//  Cada bot roda em um container isolado com:
//   • Limite de RAM (config.DOCKER_MEMORY_LIMIT_MB)

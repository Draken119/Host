// ============================================================
//  database/mongo.js — Conexão singleton com MongoDB
//  Usado exclusivamente pelo sistema de usuários
// ============================================================

const { MongoClient } = require('mongodb');
const logger          = require('../utils/logger');

let client = null;
let db     = null;

// ─────────────────────────────────────────────────────────
//  connect — chame uma vez no boot (index.js)
// ─────────────────────────────────────────────────────────
async function connect() {
  if (db) return db;

  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error('[MONGO] MONGODB_URI não definida no .env');
  }

  client = new MongoClient(uri);
  await client.connect();

  const dbName = process.env.MONGODB_DB || 'host_bot';
  db = client.db(dbName);

  // Garante índice único no discord_id para evitar duplicatas
  await db.collection('users').createIndex({ discord_id: 1 }, { unique: true });

  logger.ok(`[MONGO] Conectado ao banco "${dbName}"`);
  return db;
}

// ─────────────────────────────────────────────────────────
//  getDb — retorna a instância de db já conectada
// ─────────────────────────────────────────────────────────
function getDb() {
  if (!db) throw new Error('[MONGO] MongoDB não conectado. Chame connect() primeiro.');
  return db;
}

// ─────────────────────────────────────────────────────────
//  disconnect — graceful shutdown
// ─────────────────────────────────────────────────────────
async function disconnect() {
  if (client) {
    await client.close();
    client = null;
    db     = null;
    logger.info('[MONGO] Conexão encerrada');
  }
}

module.exports = { connect, getDb, disconnect };

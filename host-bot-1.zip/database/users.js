// ============================================================
//  database/users.js — CRUD de usuários no MongoDB
//
//  Schema do documento (coleção "users"):
//  {
//    discord_id   : string   — ID único do usuário no Discord
//    username     : string   — nome de usuário (atualizado a cada uso)
//    display_name : string   — nome de exibição (global name ou username)
//    avatar       : string   — hash do avatar (pode ser null)
//    joined_at    : Date     — quando criou a conta na host
//    last_seen    : Date     — última interação registrada
//    bots_hosted  : number   — total acumulado de bots já hospedados
//    is_banned    : boolean  — bloqueado de usar a host
//    ban_reason   : string   — motivo do ban (null se não banido)
//    notes        : string   — anotação interna (admin)
//  }
// ============================================================

const { getDb } = require('./mongo');

// ─────────────────────────────────────────────────────────
//  Helpers internos
// ─────────────────────────────────────────────────────────
function col() {
  return getDb().collection('users');
}

function userFromDiscord(discordUser) {
  return {
    username:     discordUser.username,
    display_name: discordUser.globalName || discordUser.username,
    avatar:       discordUser.avatar || null,
  };
}

// ─────────────────────────────────────────────────────────
//  getUser — retorna o documento do usuário ou null
// ─────────────────────────────────────────────────────────
async function getUser(discordId) {
  return col().findOne({ discord_id: discordId });
}

// ─────────────────────────────────────────────────────────
//  upsertUser — cria ou atualiza ao interagir com a host
//  Atualiza username, avatar e last_seen automaticamente
// ─────────────────────────────────────────────────────────
async function upsertUser(discordUser) {
  const now = new Date();

  await col().updateOne(
    { discord_id: discordUser.id },
    {
      $setOnInsert: {
        discord_id:  discordUser.id,
        joined_at:   now,
        bots_hosted: 0,
        is_banned:   false,
        ban_reason:  null,
        notes:       null,
      },
      $set: {
        ...userFromDiscord(discordUser),
        last_seen: now,
      },
    },
    { upsert: true }
  );

  return col().findOne({ discord_id: discordUser.id });
}

// ─────────────────────────────────────────────────────────
//  incrementBotsHosted — chamado ao hospedar um bot com /up
// ─────────────────────────────────────────────────────────
async function incrementBotsHosted(discordId) {
  await col().updateOne(
    { discord_id: discordId },
    { $inc: { bots_hosted: 1 } }
  );
}

// ─────────────────────────────────────────────────────────
//  updateLastSeen — atualiza a última interação
// ─────────────────────────────────────────────────────────
async function updateLastSeen(discordId) {
  await col().updateOne(
    { discord_id: discordId },
    { $set: { last_seen: new Date() } }
  );
}

// ─────────────────────────────────────────────────────────
//  banUser / unbanUser — controle de acesso
// ─────────────────────────────────────────────────────────
async function banUser(discordId, reason = 'Sem motivo informado') {
  const result = await col().updateOne(
    { discord_id: discordId },
    { $set: { is_banned: true, ban_reason: reason } }
  );
  return result.matchedCount > 0;
}

async function unbanUser(discordId) {
  const result = await col().updateOne(
    { discord_id: discordId },
    { $set: { is_banned: false, ban_reason: null } }
  );
  return result.matchedCount > 0;
}

// ─────────────────────────────────────────────────────────
//  isBanned — verificação rápida usada nos comandos
// ─────────────────────────────────────────────────────────
async function isBanned(discordId) {
  const user = await col().findOne(
    { discord_id: discordId },
    { projection: { is_banned: 1, ban_reason: 1 } }
  );
  if (!user) return { banned: false };
  return { banned: user.is_banned, reason: user.ban_reason };
}

// ─────────────────────────────────────────────────────────
//  setNotes — anotação admin sobre o usuário
// ─────────────────────────────────────────────────────────
async function setNotes(discordId, notes) {
  await col().updateOne(
    { discord_id: discordId },
    { $set: { notes } }
  );
}

// ─────────────────────────────────────────────────────────
//  listUsers — para uso admin (paginado)
// ─────────────────────────────────────────────────────────
async function listUsers({ page = 0, limit = 20, banned = null } = {}) {
  const filter = {};
  if (banned !== null) filter.is_banned = banned;

  const total = await col().countDocuments(filter);
  const users = await col()
    .find(filter)
    .sort({ joined_at: -1 })
    .skip(page * limit)
    .limit(limit)
    .toArray();

  return { users, total, page, pages: Math.ceil(total / limit) };
}

module.exports = {
  getUser,
  upsertUser,
  incrementBotsHosted,
  updateLastSeen,
  banUser,
  unbanUser,
  isBanned,
  setNotes,
  listUsers,
};

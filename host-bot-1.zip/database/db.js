// ============================================================
//  database/db.js — Banco de dados usando lowdb (puro JS)
//  Sem compilação nativa — funciona em qualquer plataforma
// ============================================================

const low      = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');
const fs       = require('fs');
const pathMod  = require('path');
const config   = require('../config');

// ── Garante que o diretório existe ────────────────────────
const dbDir = pathMod.dirname(config.DB_PATH);
fs.mkdirSync(dbDir, { recursive: true });

const adapter = new FileSync(config.DB_PATH);
const db      = low(adapter);

// Define estrutura padrão se o arquivo for novo
db.defaults({ bots: [], counter: 1 }).write();

// ─────────────────────────────────────────────────────────
//  Helpers internos
// ─────────────────────────────────────────────────────────
function nextId() {
  const id = db.get('counter').value();
  db.set('counter', id + 1).write();
  return id;
}

function now() {
  return Math.floor(Date.now() / 1000);
}

// ─────────────────────────────────────────────────────────
//  toRelative — converte folder_path para relativo ao BOTS_DIR
//  Garante que o banco nunca salve caminhos absolutos do SO
// ─────────────────────────────────────────────────────────
function toRelative(folder_path) {
  const botsDir = pathMod.resolve(config.BOTS_DIR);
  const abs     = pathMod.resolve(folder_path);
  // Se já é relativo ou está dentro do BOTS_DIR, usa relativo
  if (abs.startsWith(botsDir)) {
    return pathMod.relative(botsDir, abs);
  }
  // Fallback: salva só os últimos 2 segmentos (userId/botName)
  const parts = abs.replace(/\\/g, '/').split('/');
  return parts.slice(-2).join('/');
}

// ─────────────────────────────────────────────────────────
//  toAbsolute — resolve folder_path para absoluto no SO atual
// ─────────────────────────────────────────────────────────
function toAbsolute(folder_path) {
  if (pathMod.isAbsolute(folder_path)) {
    // Caminho absoluto antigo (Windows) — recalcula pelo BOTS_DIR atual
    const basename  = pathMod.basename(folder_path);
    const parentDir = pathMod.basename(pathMod.dirname(folder_path));
    return pathMod.join(config.BOTS_DIR, parentDir, basename);
  }
  return pathMod.join(config.BOTS_DIR, folder_path);
}

// ─────────────────────────────────────────────────────────
//  resolveBot — adiciona folder_path absoluto em um bot
// ─────────────────────────────────────────────────────────
function resolveBot(bot) {
  if (!bot) return null;
  return { ...bot, folder_path: toAbsolute(bot.folder_path) };
}

// ─────────────────────────────────────────────────────────
//  API pública
// ─────────────────────────────────────────────────────────
function createBot({ bot_name, user_id, start_cmd, folder_path, memory = 256 }) {
  const id  = nextId();
  const bot = {
    id, bot_name, user_id,
    pid: null, status: 'installing',
    start_cmd,
    folder_path: toRelative(folder_path), // sempre salva relativo
    memory,
    created_at: now(), started_at: null, restart_count: 0,
  };
  db.get('bots').push(bot).write();
  return id;
}

function updateBot(id, fields) {
  // Se estiver atualizando folder_path, salva relativo
  if (fields.folder_path) {
    fields = { ...fields, folder_path: toRelative(fields.folder_path) };
  }
  db.get('bots').find({ id }).assign(fields).write();
}

function getBotsByUser(user_id) {
  return db.get('bots').filter({ user_id }).value().map(resolveBot);
}

function getBotById(id) {
  return resolveBot(db.get('bots').find({ id }).value() || null);
}

function getBotByName(user_id, bot_name) {
  return resolveBot(db.get('bots').find({ user_id, bot_name }).value() || null);
}

function deleteBot(id) {
  db.get('bots').remove({ id }).write();
}

function countUserBots(user_id) {
  return db.get('bots').filter({ user_id }).size().value();
}

function getRunningBots() {
  return db.get('bots').filter({ status: 'running' }).value().map(resolveBot);
}

module.exports = {
  db, createBot, updateBot,
  getBotsByUser, getBotById, getBotByName,
  deleteBot, countUserBots, getRunningBots,
};

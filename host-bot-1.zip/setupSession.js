// ============================================================
//  services/setupSession.js — Fluxo guiado do /up
//
//  Etapas:
//   1. Zip   — baixado imediatamente, manifest lido
//   2. Token — sempre pedido (segurança)
//   3. Confirmação — mostra resumo do host.config e confirma
// ============================================================

const {
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ComponentType,
} = require('discord.js');

const fs         = require('fs');
const fsp        = require('fs/promises');
const path       = require('path');
const config     = require('../config');
const logger     = require('../utils/logger');
const { readManifestFromZip } = require('../utils/manifest');
const lm         = require('../utils/logManager');

// ── Sessões ativas ─────────────────────────────────────────
const sessions = new Map();

// ── Etapas ────────────────────────────────────────────────
// Apenas 2 etapas manuais — o resto vem do host.config
const STEPS = [
  {
    key:    'zip',
    label:  'Arquivo .zip',
    prompt: [
      '📎 **Envie o arquivo `.zip`** do seu bot.',
      '',
      '> O zip deve conter um arquivo **`host.config`** na raiz.',
      '> Use `/template` para baixar o modelo.',
      `> Máximo **${config.MAX_ZIP_SIZE_MB}MB**.`,
    ].join('\n'),
  },
  {
    key:    'token',
    label:  'Token',
    prompt: [
      '🔑 **Envie o token** do seu bot Discord.',
      '',
      '> ⚠️ Sua mensagem será **deletada imediatamente** por segurança.',
      '> Encontre o token em: discord.com/developers → Bot → Reset Token',
    ].join('\n'),
  },
];

// ─────────────────────────────────────────────────────────
//  buildEmbed
// ─────────────────────────────────────────────────────────
function buildEmbed(session, status = null, statusDesc = null) {
  const { step, manifest } = session;

  const stepLines = STEPS.map((s, i) => {
    const icon = i < step  ? '✅' :
                 i === step ? (status === 'processing' ? '⚙️' : '▶️') : '⬜';

    let suffix = '';
    if (i < step) {
      if      (s.key === 'token') suffix = ' → `••••••••`';
      else if (s.key === 'zip' && session.data.zipName) suffix = ` → \`${session.data.zipName}\``;
    }
    return `${icon} **${s.label}**${suffix}`;
  });

  const colors = { null: 0x5865F2, processing: 0xFEE75C, success: 0x57F287, error: 0xED4245, timeout: 0xED4245, cancelled: 0x95a5a6 };
  const titles = {
    null:         `🤖 Configuração — Etapa ${Math.min(step + 1, STEPS.length)}/${STEPS.length}`,
    processing:   '⚙️ Processando...',
    success:      '✅ Bot iniciado com sucesso!',
    error:        '❌ Erro na configuração',
    timeout:      '⏰ Sessão expirada',
    cancelled:    '🚫 Cancelado',
  };

  const embed = new EmbedBuilder()
    .setColor(colors[status] ?? 0x5865F2)
    .setTitle(titles[status] ?? titles[null])
    .setDescription(stepLines.join('\n'))
    .setFooter({ text: 'Digite "cancelar" a qualquer momento para sair.' })
    .setTimestamp();

  // Mostra prompt da etapa atual
  if (status === null && step < STEPS.length) {
    embed.addFields({ name: '💬 Próximo passo', value: STEPS[step].prompt });
  }

  // Mostra dados do manifest se já foram lidos
  if (manifest && status !== 'error' && status !== 'cancelled') {
    embed.addFields({
      name:  '📋 Dados do host.config',
      value: [
        `**Nome:** \`${manifest.DISPLAY_NAME}\``,
        `**Arquivo:** \`${manifest.MAIN}\``,
        `**Comando:** \`${manifest.START_CMD}\``,
        `**Memória:** \`${manifest.MEMORY}MB\``,
        `**Auto-restart:** \`${manifest.AUTORESTART ? 'Sim' : 'Não'}\``,
        manifest.DESCRIPTION ? `**Descrição:** ${manifest.DESCRIPTION}` : '',
      ].filter(Boolean).join('\n'),
    });
  }

  if (statusDesc) {
    embed.addFields({ name: '\u200B', value: statusDesc });
  }

  return embed;
}

// ─────────────────────────────────────────────────────────
//  downloadAttachment — undici sem header de auth
// ─────────────────────────────────────────────────────────
async function downloadAttachment(att, destPath) {
  const { fetch: undiciFetch } = require('undici');

  const response = await undiciFetch(att.url, {
    method:  'GET',
    redirect: 'follow',
    headers:  { 'User-Agent': 'Mozilla/5.0' },
  });

  if (!response.ok) {
    throw new Error(`Falha ao baixar o arquivo (HTTP ${response.status}).`);
  }

  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length === 0) throw new Error('Arquivo baixado está vazio.');

  await fsp.writeFile(destPath, buffer);
}

// ─────────────────────────────────────────────────────────
//  createSetupChannel
// ─────────────────────────────────────────────────────────
async function createSetupChannel(interaction) {
  const guild = interaction.guild;
  const user  = interaction.user;
  const name  = `setup-${user.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || 'user'}`;

  const permissionOverwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id:    user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
      ],
    },
    {
      id:    interaction.client.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.EmbedLinks,
      ],
    },
  ];

  const opts = { name, type: ChannelType.GuildText, topic: `Configuração — ${user.tag}`, permissionOverwrites };
  if (config.SETUP_CATEGORY_ID) opts.parent = config.SETUP_CATEGORY_ID;

  return guild.channels.create(opts);
}

// ─────────────────────────────────────────────────────────
//  startSession
// ─────────────────────────────────────────────────────────
async function startSession(interaction) {
  for (const [, s] of sessions) {
    if (s.userId === interaction.user.id) {
      return interaction.reply({
        content: `❌ Você já tem uma sessão ativa em <#${s.channelId}>!`,
        ephemeral: true,
      });
    }
  }

  let channel;
  try {
    channel = await createSetupChannel(interaction);
  } catch (err) {
    logger.error('[SESSION] Erro ao criar canal:', err.message);
    return interaction.reply({
      content: `❌ Não consegui criar o canal.\nVerifique se tenho permissão de **Gerenciar Canais**.\n\`${err.message}\``,
      ephemeral: true,
    });
  }

  await interaction.reply({
    content: `✅ Canal criado: ${channel} — Vá até lá para continuar!`,
    ephemeral: true,
  });

  const session = {
    userId:    interaction.user.id,
    channelId: channel.id,
    channel,
    step:      0,
    data:      {},
    manifest:  null,   // preenchido ao ler o host.config
    botMsg:    null,
    timeout:   null,
  };

  sessions.set(channel.id, session);

  const botMsg = await channel.send({
    content: `👋 <@${interaction.user.id}>, vamos configurar seu bot!`,
    embeds:  [buildEmbed(session)],
  });

  session.botMsg = botMsg;
  resetTimeout(session);
  logger.info(`[SESSION] Iniciada para ${interaction.user.tag}`);
}

// ─────────────────────────────────────────────────────────
//  handleMessage
// ─────────────────────────────────────────────────────────
async function handleMessage(message) {
  const session = sessions.get(message.channelId);
  if (!session || message.author.id !== session.userId || message.author.bot) return;

  resetTimeout(session);

  if (message.content.trim().toLowerCase() === 'cancelar') {
    await message.delete().catch(() => {});
    return finishSession(session, 'cancelled', 'Configuração cancelada.');
  }

  const step = STEPS[session.step];
  if (!step) return;

  try {
    await collectStep(session, message, step);
  } catch (err) {
    await message.delete().catch(() => {});
    const errMsg = await message.channel.send(`❌ ${err.message}`);
    setTimeout(() => errMsg.delete().catch(() => {}), 8_000);
  }
}

// ─────────────────────────────────────────────────────────
//  collectStep
// ─────────────────────────────────────────────────────────
async function collectStep(session, message, step) {
  switch (step.key) {

    // ── ETAPA 1: ZIP ──────────────────────────────────────
    case 'zip': {
      const att = message.attachments.first();

      if (!att)
        throw new Error('Nenhum arquivo detectado. Envie o `.zip` como **anexo** da mensagem.');
      if (!att.name.toLowerCase().endsWith('.zip'))
        throw new Error('O arquivo deve ter extensão **`.zip`**.');
      if (att.size > config.MAX_ZIP_SIZE_BYTES)
        throw new Error(`Arquivo muito grande: \`${(att.size / 1024 / 1024).toFixed(1)}MB\` — máximo ${config.MAX_ZIP_SIZE_MB}MB.`);

      // Mostra feedback antes de baixar
      await session.botMsg.edit({
        embeds: [buildEmbed(session, 'processing', '⬇️ Baixando arquivo...')],
      });

      // Garante pasta do usuário
      const userFolder = path.join(config.BOTS_DIR, session.userId);
      await fsp.mkdir(userFolder, { recursive: true });

      // Baixa PRIMEIRO, deleta mensagem DEPOIS
      const tmpPath = path.join(userFolder, `upload_${Date.now()}.zip`);
      logger.info(`[DL] Baixando: ${att.url.slice(0, 80)}...`);

      await downloadAttachment(att, tmpPath);
      logger.ok(`[DL] Download OK (${(att.size / 1024).toFixed(0)}KB)`);

      // Só deleta após o download
      await message.delete().catch(() => {});

      // Lê e valida o host.config de dentro do zip
      await session.botMsg.edit({
        embeds: [buildEmbed(session, 'processing', '📋 Lendo `host.config`...')],
      });

      let manifest;
      try {
        manifest = await readManifestFromZip(tmpPath);
      } catch (err) {
        // Limpa o zip temporário em caso de falha
        fsp.unlink(tmpPath).catch(() => {});
        throw err; // repassa — vai mostrar erro na tela
      }

      // Verifica nome duplicado já aqui (UX melhor)
      const db = require('../database/db');
      const existing = db.getBotByName(session.userId, manifest.DISPLAY_NAME);
      if (existing) {
        fsp.unlink(tmpPath).catch(() => {});
        throw new Error(
          `Você já tem um bot chamado **${manifest.DISPLAY_NAME}** (do host.config).\n` +
          `Delete-o com \`/delete\` ou altere o \`DISPLAY_NAME\` no host.config.`
        );
      }

      session.data.zipLocalPath = tmpPath;
      session.data.zipName      = att.name;
      session.manifest          = manifest;

      // Se o bot é Python, exige requirements.txt no zip
      if (manifest.MAIN.endsWith('.py')) {
        await session.botMsg.edit({
          embeds: [buildEmbed(session, 'processing', '📋 Verificando `requirements.txt`...')],
        });

        const unzipper2 = require('unzipper');
        const directory2 = await unzipper2.Open.file(tmpPath);
        const hasRequirements = directory2.files.some(f =>
          f.path === 'requirements.txt' || f.path.match(/^[^/]+\/requirements\.txt$/)
        );

        if (!hasRequirements) {
          fsp.unlink(tmpPath).catch(() => {});
          throw new Error(
            '**`requirements.txt` não encontrado** no zip.\n\n' +
            '> Bots Python precisam de um `requirements.txt` na raiz do zip com todas as dependências.\n' +
            '> Mesmo que não tenha dependências externas, crie o arquivo vazio.\n\n' +
            '**Exemplo de `requirements.txt`:**\n```\ndiscord.py\nrequests\n```'
          );
        }
      }

      break;
    }

    // ── ETAPA 2: TOKEN ────────────────────────────────────
    case 'token': {
      // Deleta IMEDIATAMENTE — máxima prioridade de segurança
      await message.delete().catch(() => {});

      const content = message.content.trim();
      if (!content) throw new Error('Token não pode ser vazio.');
      if (content.length < 50)
        throw new Error('Token inválido (muito curto). Copie o token completo do Discord Developer Portal.');

      session.data.token = content;
      break;
    }
  }

  session.step++;

  if (session.step < STEPS.length) {
    // Próxima etapa
    await session.botMsg.edit({ embeds: [buildEmbed(session)] });
  } else {
    // Todas as etapas coletadas → confirmação
    await askConfirmation(session);
  }
}

// ─────────────────────────────────────────────────────────
//  askConfirmation — botões de confirmar/cancelar
// ─────────────────────────────────────────────────────────
async function askConfirmation(session) {
  const { manifest } = session;

  const confirmBtn = new ButtonBuilder()
    .setCustomId(`confirm_up_${session.channelId}`)
    .setLabel('✅ Confirmar e hospedar')
    .setStyle(ButtonStyle.Success);

  const cancelBtn = new ButtonBuilder()
    .setCustomId(`cancel_up_${session.channelId}`)
    .setLabel('❌ Cancelar')
    .setStyle(ButtonStyle.Secondary);

  const row = new ActionRowBuilder().addComponents(confirmBtn, cancelBtn);

  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle('🔍 Confirme as informações')
    .setDescription('Revise os dados abaixo antes de hospedar:')
    .addFields(
      { name: '🤖 Nome',          value: `\`${manifest.DISPLAY_NAME}\``,                   inline: true  },
      { name: '📄 Arquivo',       value: `\`${manifest.MAIN}\``,                           inline: true  },
      { name: '▶️ Comando',       value: `\`${manifest.START_CMD}\``,                      inline: false },
      { name: '💾 Memória',       value: `\`${manifest.MEMORY}MB\``,                       inline: true  },
      { name: '🔁 Auto-restart',  value: `\`${manifest.AUTORESTART ? 'Sim' : 'Não'}\``,   inline: true  },
      { name: '🔑 Token',         value: '`••••••••` (recebido)',                           inline: true  },
    )
    .setFooter({ text: 'Você tem 60 segundos para confirmar.' })
    .setTimestamp();

  if (manifest.DESCRIPTION) {
    embed.addFields({ name: '📝 Descrição', value: manifest.DESCRIPTION, inline: false });
  }

  await session.botMsg.edit({ content: `<@${session.userId}>`, embeds: [embed], components: [row] });

  // Aguarda clique
  try {
    const btn = await session.botMsg.awaitMessageComponent({
      filter:        (i) => i.user.id === session.userId,
      time:          60_000,
      componentType: ComponentType.Button,
    });

    await btn.deferUpdate();

    if (btn.customId.startsWith('cancel_up_')) {
      // Limpa zip temporário
      fsp.unlink(session.data.zipLocalPath).catch(() => {});
      return finishSession(session, 'cancelled', 'Hospedagem cancelada pelo usuário.');
    }

    // Confirmado — processa
    await session.botMsg.edit({ components: [] });
    await processBot(session);

  } catch (_) {
    // Timeout
    fsp.unlink(session.data.zipLocalPath).catch(() => {});
    await finishSession(session, 'timeout', 'Confirmação não recebida a tempo.');
  }
}

// ─────────────────────────────────────────────────────────
//  processBot
// ─────────────────────────────────────────────────────────
async function processBot(session) {
  const db       = require('../database/db');
  const pm       = require('../processManager');
  const bm       = require('../botManager');
  const unzipper = require('unzipper');

  const { userId, data, manifest } = session;

  const onProgress = async (msg) => {
    await session.botMsg.edit({
      embeds: [buildEmbed(session, 'processing', msg)],
    }).catch(() => {});
  };

  await onProgress('⏳ Iniciando...');

  // Limite de bots
  if (db.countUserBots(userId) >= config.MAX_BOTS_PER_USER) {
    fsp.unlink(data.zipLocalPath).catch(() => {});
    return finishSession(session, 'error',
      `Você atingiu o limite de **${config.MAX_BOTS_PER_USER}** bots.\nUse \`/delete\` para remover um primeiro.`
    );
  }

  const botName    = manifest.DISPLAY_NAME;
  const startCmd   = manifest.START_CMD;
  const folderPath = path.join(config.BOTS_DIR, userId, bm.sanitizeName(botName));

  const botId = db.createBot({
    bot_name:    botName,
    user_id:     userId,
    start_cmd:   startCmd,
    folder_path: folderPath,
    memory:      manifest.MEMORY,
  });

  try {
    // Valida conteúdo do zip (extensões bloqueadas)
    await onProgress('🔍 Validando conteúdo do zip...');
    const blocked   = config.BLOCKED_EXTENSIONS;
    const directory = await unzipper.Open.file(data.zipLocalPath);
    for (const file of directory.files) {
      const ext = path.extname(file.path).toLowerCase();
      if (blocked.includes(ext))
        throw new Error(`Arquivo bloqueado no zip: \`${file.path}\``);
      if (file.path.includes('..'))
        throw new Error(`Path traversal detectado: \`${file.path}\``);
    }

    // Extrai
    await onProgress('📦 Extraindo arquivos...');
    await fsp.mkdir(folderPath, { recursive: true });
    await new Promise((res, rej) => {
      fs.createReadStream(data.zipLocalPath)
        .pipe(unzipper.Extract({ path: folderPath }))
        .on('close', res)
        .on('error', rej);
    });

    // Remove pasta raiz se o zip foi criado comprimindo uma pasta
    await bm.stripRootFolder(folderPath);

    // Escaneia o código e pré-cria pastas/arquivos que o bot vai precisar
    await bm.preSeedBotDirs(folderPath);

    // Cria .env
    await onProgress('🔑 Configurando variáveis de ambiente...');
    await bm.createEnvFile(folderPath, data.token);

    // Instala dependências
    const { warnings: installWarnings } = await bm.installDependencies(folderPath, onProgress);

    // Inicia processo
    await onProgress('🚀 Iniciando o bot...');
    const pid = await pm.startProcess(botId, folderPath, startCmd, manifest.AUTORESTART);

    const runtime = bm.detectRuntime(folderPath);
    const runtimeLabel = { node: '🟨 Node.js', python: '🐍 Python', both: '🟨🐍 Node + Python', none: '📦' }[runtime] || '📦';

    lm.writeHostLog('INFO', `Bot "${botName}" (ID ${botId}, PID ${pid}) hospedado por ${userId}`);
    logger.ok(`[SESSION] Bot "${botName}" iniciado (PID ${pid})`);

    await finishSession(session, 'success', [
      `**Nome:** \`${botName}\``,
      `**Runtime:** ${runtimeLabel}`,
      `**PID:** \`${pid}\``,
      `**Memória:** \`${manifest.MEMORY}MB\``,
      `**Auto-restart:** \`${manifest.AUTORESTART ? 'Sim' : 'Não'}\``,
      '',
      '> Use `/status`, `/logs`, `/restart` e `/stop` para gerenciar.',
      installWarnings.length > 0 ? '\n⚠️ **Pacotes não instalados (precisam de libs nativas do SO):**\n' + installWarnings.map(w => { const p = w.split(':'); return '• `' + (p[1]||w) + '` — ' + p.slice(2).join(':'); }).join('\n') : '',
    ].filter(Boolean).join('\n'));

  } catch (err) {
    logger.error('[SESSION] Erro:', err.message);
    db.deleteBot(botId);
    bm.deleteFolder(folderPath).catch(() => {});
    await finishSession(session, 'error', err.message);
  } finally {
    fsp.unlink(data.zipLocalPath).catch(() => {});
  }
}

// ─────────────────────────────────────────────────────────
//  finishSession
// ─────────────────────────────────────────────────────────
async function finishSession(session, status, description) {
  clearTimeout(session.timeout);
  sessions.delete(session.channelId);

  const delay = config.SETUP_CLOSE_DELAY_MS;
  const msgs  = { success: `✅`, error: `❌`, timeout: `⏰`, cancelled: `🚫` };

  await session.botMsg.edit({
    content:    `<@${session.userId}> ${msgs[status] ?? ''} Canal deletado em **${delay / 1000}s**.`,
    embeds:     [buildEmbed(session, status, description)],
    components: [],
  }).catch(() => {});

  setTimeout(async () => {
    try { await session.channel.delete(); } catch (_) {}
  }, delay);
}

// ─────────────────────────────────────────────────────────
//  resetTimeout
// ─────────────────────────────────────────────────────────
function resetTimeout(session) {
  clearTimeout(session.timeout);
  session.timeout = setTimeout(async () => {
    sessions.delete(session.channelId);
    await finishSession(session, 'timeout',
      `Inatividade por **${config.SETUP_TIMEOUT_MS / 1000}s**. Sessão encerrada.`
    );
  }, config.SETUP_TIMEOUT_MS);
}

function hasSession(channelId) {
  return sessions.has(channelId);
}

module.exports = { startSession, handleMessage, hasSession, sessions };

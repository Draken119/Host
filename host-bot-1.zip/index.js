// ============================================================
//  index.js — Ponto de entrada do Host Bot
//  Bot de hospedagem com sistema de vendas VPS integrado
// ============================================================

'use strict';
require('dotenv').config();

const {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  Collection,
} = require('discord.js');

const path    = require('path');
const fs      = require('fs');
const logger  = require('./utils/logger');
const mongo   = require('./database/mongo');
const pm      = require('./processManager');
const lm      = require('./utils/logManager');
const vendas  = require('./vendas');

// ─────────────────────────────────────────────────────────
//  Valida variáveis obrigatórias
// ─────────────────────────────────────────────────────────
const REQUIRED_ENV = ['HOST_TOKEN', 'CLIENT_ID', 'MONGODB_URI', 'MERCADOPAGO_ACCESS_TOKEN'];
for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    logger.error(`[BOOT] Variável ${key} não definida no .env. Abortando.`);
    process.exit(1);
  }
}

// ─────────────────────────────────────────────────────────
//  MercadoPago
// ─────────────────────────────────────────────────────────
let mpPayment;
try {
  const mp = require('mercadopago');
  const client = new mp.MercadoPagoConfig({ accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN });
  mpPayment = new mp.Payment(client);
  logger.ok('[BOOT] MercadoPago configurado.');
} catch (e) {
  logger.error('[BOOT] Falha ao carregar mercadopago:', e.message);
  logger.warn('[BOOT] Continuando sem sistema de vendas (instale: npm install mercadopago)');
  mpPayment = null;
}

// ─────────────────────────────────────────────────────────
//  Cliente Discord
// ─────────────────────────────────────────────────────────
const bot = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
  partials: [Partials.Message, Partials.Channel],
});

// ─────────────────────────────────────────────────────────
//  Carrega comandos da pasta /commands
// ─────────────────────────────────────────────────────────
const commands     = new Collection();
const cmdData      = [];
const commandsPath = path.join(__dirname, 'commands');

if (fs.existsSync(commandsPath)) {
  for (const file of fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'))) {
    const cmd = require(path.join(commandsPath, file));
    if (cmd.data && cmd.execute) {
      commands.set(cmd.data.name, cmd);
      cmdData.push(cmd.data.toJSON());
      logger.info(`[CMDS] Carregado: /${cmd.data.name}`);
    }
  }
}

// ─────────────────────────────────────────────────────────
//  Registra slash commands (host + vendas) no Discord
// ─────────────────────────────────────────────────────────
async function registrarComandos() {
  const todos = [
    ...cmdData,
    ...vendas.slashCommands.map(c => c.toJSON()),
  ];

  const rest = new REST({ version: '10' }).setToken(process.env.HOST_TOKEN);
  try {
    const guildId = process.env.GUILD_ID;
    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, guildId), { body: todos });
      logger.ok(`[CMDS] ${todos.length} comandos registrados no servidor ${guildId}`);
    } else {
      await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: todos });
      logger.ok(`[CMDS] ${todos.length} comandos registrados globalmente`);
    }
  } catch (e) {
    logger.error('[CMDS] Erro ao registrar comandos:', e.message);
  }
}

// ─────────────────────────────────────────────────────────
//  Bot pronto
// ─────────────────────────────────────────────────────────
bot.once('ready', async () => {
  logger.ok(`[DISCORD] Logado como ${bot.user.tag}`);

  // Conecta MongoDB
  const db = await mongo.connect();

  // Inicializa módulo de vendas
  if (mpPayment) {
    vendas.init(bot, mpPayment, db);
    logger.ok('[BOOT] Sistema de vendas VPS ativo.');
  } else {
    logger.warn('[BOOT] Sistema de vendas desativado (mercadopago ausente).');
  }

  // Registra comandos
  await registrarComandos();

  // Reinicia bots que estavam rodando antes do restart
  try {
    const { getRunningBots } = require('./database/db');
    const running = getRunningBots();
    for (const b of running) {
      logger.info(`[PM] Reiniciando bot persistente: ${b.bot_name} (ID ${b.id})`);
      pm.startProcess(b.id, b.folder_path, b.start_cmd, true, b.memory).catch(e => {
        logger.error(`[PM] Falha ao reiniciar ${b.bot_name}:`, e.message);
      });
    }
  } catch (e) {
    logger.warn('[PM] Não foi possível recuperar bots persistentes:', e.message);
  }

  logger.ok('[BOOT] Host Bot pronto!');
});

// ─────────────────────────────────────────────────────────
//  Interações
// ─────────────────────────────────────────────────────────
bot.on('interactionCreate', async (interaction) => {
  // Tenta delegar ao módulo de vendas primeiro
  if (mpPayment && await vendas.handleInteraction(interaction)) return;

  // Slash Commands do host
  if (interaction.isChatInputCommand()) {
    const cmd = commands.get(interaction.commandName);
    if (!cmd) return;

    try {
      // Atualiza last_seen sem bloquear
      require('./database/users').updateLastSeen(interaction.user.id).catch(() => {});
      await cmd.execute(interaction);
    } catch (e) {
      logger.error(`[CMD] Erro em /${interaction.commandName}:`, e.message);
      const msg = { content: `❌ Erro ao executar o comando: \`${e.message}\``, ephemeral: true };
      if (interaction.replied || interaction.deferred) await interaction.followUp(msg).catch(() => {});
      else await interaction.reply(msg).catch(() => {});
    }
    return;
  }

  // Mensagens de configuração (setup session)
  if (interaction.isButton() || interaction.isStringSelectMenu()) {
    const { sessions } = require('./services/setupSession');
    if (sessions.has(interaction.channelId)) {
      // setup session lida internamente via handleMessage e botões
    }

    // Botões de delete
    if (interaction.isButton() && interaction.customId.startsWith('del_confirm_')) {
      const botId = parseInt(interaction.customId.replace('del_confirm_', ''));
      const { getBotById, deleteBot } = require('./database/db');
      const bm = require('./botManager');
      const target = getBotById(botId);
      if (!target || target.user_id !== interaction.user.id) {
        return interaction.update({ content: '❌ Bot não encontrado.', embeds: [], components: [] });
      }
      if (pm.isRunning(botId)) await pm.killProcess(botId);
      lm.clearBotLogs(botId);
      await bm.deleteFolder(target.folder_path);
      deleteBot(botId);
      return interaction.update({ content: `🗑️ Bot **${target.bot_name}** deletado!`, embeds: [], components: [] });
    }

    if (interaction.isButton() && interaction.customId === 'del_cancel') {
      return interaction.update({ content: '✅ Cancelado.', embeds: [], components: [] });
    }

    // Selects de start/stop/restart/logs/status
    if (interaction.isStringSelectMenu()) {
      const { getBotById } = require('./database/db');
      const customId = interaction.customId;
      const botId    = parseInt(interaction.values[0]);
      const target   = getBotById(botId);
      if (!target || target.user_id !== interaction.user.id) {
        return interaction.update({ content: '❌ Bot não encontrado.', components: [] });
      }

      if (customId === 'start_select_bot') {
        await interaction.deferUpdate();
        await pm.startProcess(target.id, target.folder_path, target.start_cmd, true, target.memory);
        return interaction.editReply({ content: `✅ **${target.bot_name}** iniciado!`, components: [] });
      }
      if (customId === 'stop_select_bot') {
        await interaction.deferUpdate();
        await pm.killProcess(target.id);
        return interaction.editReply({ content: `⏹️ **${target.bot_name}** parado.`, components: [] });
      }
      if (customId === 'restart_select_bot') {
        await interaction.deferUpdate();
        if (pm.isRunning(target.id)) await pm.killProcess(target.id);
        await new Promise(r => setTimeout(r, 1500));
        await pm.startProcess(target.id, target.folder_path, target.start_cmd, true, target.memory);
        return interaction.editReply({ content: `🔄 **${target.bot_name}** reiniciado!`, components: [] });
      }
      if (customId === 'logs_select_bot') {
        await interaction.deferUpdate();
        const lines = lm.getMemoryLogs(target.id, 20);
        const texto = lines.length ? lines.join('\n') : 'Sem logs disponíveis.';
        if (texto.length > 1900) {
          return interaction.editReply({ content: `📄 Logs de **${target.bot_name}**:`, files: [{ attachment: Buffer.from(texto), name: 'logs.txt' }], components: [] });
        }
        return interaction.editReply({ content: `📄 **${target.bot_name}**:\n\`\`\`\n${texto}\n\`\`\``, components: [] });
      }
      if (customId === 'status_select_bot') {
        await interaction.deferUpdate();
        const embeds = require('./utils/embeds');
        const stats  = pm.getStats(target.id);
        return interaction.editReply({ embeds: [embeds.status(target.bot_name, target, stats)], components: [] });
      }
      if (customId === 'delete_select_bot') {
        const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`del_confirm_${target.id}`).setLabel('Sim, deletar').setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId('del_cancel').setLabel('Cancelar').setStyle(ButtonStyle.Secondary),
        );
        return interaction.update({
          content: '',
          embeds: [new EmbedBuilder().setTitle('⚠️ Confirmar exclusão').setDescription(`Deletar **${target.bot_name}**?\nArquivos serão removidos permanentemente.`).setColor(0xED4245)],
          components: [row],
        });
      }
    }
  }
});

// ─────────────────────────────────────────────────────────
//  Mensagens do canal de setup
// ─────────────────────────────────────────────────────────
bot.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  const { handleMessage, hasSession } = require('./services/setupSession');
  if (hasSession(message.channelId)) {
    await handleMessage(message).catch(e => logger.error('[SESSION] handleMessage:', e.message));
  }
});

// ─────────────────────────────────────────────────────────
//  Graceful shutdown
// ─────────────────────────────────────────────────────────
async function shutdown(signal) {
  logger.warn(`[SHUTDOWN] Sinal ${signal} recebido. Encerrando...`);
  try {
    const { getRunningBots } = require('./database/db');
    for (const b of getRunningBots()) {
      logger.info(`[PM] Parando container ${b.bot_name}...`);
      await pm.killProcess(b.id).catch(() => {});
    }
  } catch { /* silencia */ }
  await mongo.disconnect();
  bot.destroy();
  process.exit(0);
}

process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('uncaughtException', (e) => { logger.error('[UNCAUGHT]', e); });
process.on('unhandledRejection', (r) => { logger.warn('[UNHANDLED]', r); });

// ─────────────────────────────────────────────────────────
//  Login
// ─────────────────────────────────────────────────────────
bot.login(process.env.HOST_TOKEN).catch(e => {
  logger.error('[BOOT] Falha no login:', e.message);
  process.exit(1);
});

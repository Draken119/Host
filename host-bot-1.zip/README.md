# 🖥️ Host Bot — Hospedagem de Bots Discord

Bot de hospedagem com sistema de vendas VPS integrado, pagamento PIX automático via MercadoPago e gerenciamento via Docker.

---

## ⚡ Instalação Rápida

```bash
# 1. Instalar dependências
npm install

# 2. Configurar variáveis de ambiente
cp .env.example .env
# Edite o .env com seus dados

# 3. Iniciar
npm start
```

---

## ⚙️ Configuração (.env)

| Variável | Descrição |
|---|---|
| `HOST_TOKEN` | Token do bot Discord |
| `CLIENT_ID` | ID da aplicação Discord |
| `GUILD_ID` | ID do servidor (deixe vazio para global) |
| `MONGODB_URI` | String de conexão MongoDB Atlas |
| `MERCADOPAGO_ACCESS_TOKEN` | Token de produção do MercadoPago |
| `ADMIN_IDS` | IDs dos admins separados por vírgula |
| `VENDAS_LOG_CHANNEL` | ID do canal de log de vendas |
| `CARGO_CLIENTE_ID` | Cargo atribuído ao comprar um plano |

---

## 📦 Comandos de Hospedagem

| Comando | Descrição |
|---|---|
| `/up` | Hospeda um novo bot (.zip) |
| `/list` | Lista seus bots hospedados |
| `/status` | Status e uptime de um bot |
| `/start` | Inicia um bot parado |
| `/stop` | Para um bot em execução |
| `/restart` | Reinicia um bot |
| `/logs` | Últimos logs de um bot |
| `/delete` | Remove um bot e seus arquivos |
| `/profile` | Seu perfil na host |

## 💳 Comandos de Vendas

| Comando | Descrição |
|---|---|
| `/comprar` | Comprar ou renovar plano VPS |
| `/status_vps` | Ver plano VPS ativo |
| `/admin_vendas` | Painel admin (apenas admins) |

---

## 🗂️ Estrutura

```
host-bot/
├── index.js              ← Ponto de entrada
├── vendas.js             ← Sistema de vendas VPS (PIX)
├── botManager.js         ← Gerenciamento de arquivos dos bots
├── processManager.js     ← Gerenciamento de containers Docker
├── config.js             ← Configurações globais
├── commands/             ← Slash commands
│   ├── up.js
│   ├── list.js
│   ├── status.js
│   ├── start.js
│   ├── stop.js
│   ├── restart.js
│   ├── logs.js
│   ├── delete.js
│   ├── commit.js
│   └── profile.js
├── services/
│   └── setupSession.js   ← Fluxo guiado do /up
├── database/
│   ├── db.js             ← lowdb (bots locais)
│   ├── mongo.js          ← Conexão MongoDB
│   └── users.js          ← CRUD usuários
└── utils/
    ├── cooldown.js
    ├── embeds.js
    ├── logManager.js
    └── logger.js
```

---

## 🐳 Requisitos

- Node.js >= 18
- Docker (para rodar os bots hospedados)
- MongoDB Atlas (gratuito)
- Conta MercadoPago com PIX habilitado

// ============================================================
//  services/deploy.js — Registra os slash commands no Discord
// ============================================================

require('dotenv').config();

const { REST, Routes } = require('discord.js');
const fs     = require('fs');
const path   = require('path');
const config = require('../config');
const logger = require('../utils/logger');

async function deployCommands() {
  const commands = [];
  const cmdPath  = path.join(__dirname, '..', 'commands');

  for (const file of fs.readdirSync(cmdPath).filter(f => f.endsWith('.js'))) {
    const cmd = require(path.join(cmdPath, file));
    commands.push(cmd.data.toJSON());
    logger.info(`[DEPLOY] Carregado: /${cmd.data.name}`);
  }

  const rest = new REST({ version: '10' }).setToken(config.TOKEN);

  try {
    logger.info(`[DEPLOY] Registrando ${commands.length} comando(s)...`);

    const route = config.GUILD_ID
      ? Routes.applicationGuildCommands(config.CLIENT_ID, config.GUILD_ID)
      : Routes.applicationCommands(config.CLIENT_ID);

    const data = await rest.put(route, { body: commands });
    logger.ok(`[DEPLOY] ✅ ${data.length} comandos registrados com sucesso!`);

  } catch (err) {
    logger.error('[DEPLOY] Falha ao registrar comandos:', err.message);
    process.exit(1);
  }
}

// Permite rodar direto: node services/deploy.js
if (require.main === module) {
  deployCommands();
}

module.exports = { deployCommands };

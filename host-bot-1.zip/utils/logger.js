// ============================================================
//  utils/logger.js — Logger colorido para o console
// ============================================================

const COLORS = {
  reset:  '\x1b[0m',
  red:    '\x1b[31m',
  yellow: '\x1b[33m',
  cyan:   '\x1b[36m',
  green:  '\x1b[32m',
  gray:   '\x1b[90m',
};

function timestamp() {
  return new Date().toISOString().replace('T', ' ').slice(0, 19);
}

function log(level, color, ...args) {
  console.log(
    `${COLORS.gray}[${timestamp()}]${COLORS.reset} ${color}[${level}]${COLORS.reset}`,
    ...args
  );
}

module.exports = {
  info:  (...a) => log('INFO',  COLORS.cyan,   ...a),
  warn:  (...a) => log('WARN',  COLORS.yellow, ...a),
  error: (...a) => log('ERROR', COLORS.red,    ...a),
  ok:    (...a) => log('OK',    COLORS.green,  ...a),
  debug: (...a) => {
    if (process.env.DEBUG) log('DEBUG', COLORS.gray, ...a);
  },
};

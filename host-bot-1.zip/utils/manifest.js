// ============================================================
//  utils/manifest.js — Parser do arquivo host.config
//
//  O arquivo host.config deve estar na RAIZ do .zip
//  e seguir o formato CHAVE=VALOR (um por linha).
//  Linhas começando com # são comentários.
// ============================================================

const path    = require('path');
const logger  = require('./logger');

// ── Campos suportados e seus padrões ──────────────────────
const SCHEMA = {
  DISPLAY_NAME: { type: 'string',  required: true,  maxLen: 32  },
  MAIN:         { type: 'string',  required: true,  maxLen: 100 },
  VERSION:      { type: 'string',  required: false, default: 'recommended' },
  MEMORY:       { type: 'integer', required: false, default: 256, min: 64, max: 2048 },
  AUTORESTART:  { type: 'boolean', required: false, default: true },
  DESCRIPTION:  { type: 'string',  required: false, maxLen: 280, default: '' },
};

// ── Extensões → comando de start ──────────────────────────
const MAIN_TO_CMD = {
  '.js':  (f) => `node ${f}`,
  '.mjs': (f) => `node ${f}`,
  '.cjs': (f) => `node ${f}`,
  '.ts':  (f) => `npx ts-node ${f}`,
  '.tsx': (f) => `npx ts-node ${f}`,
  '.py':  (f) => `python3 ${f}`,
};

// ─────────────────────────────────────────────────────────
//  parseManifest — lê e valida o host.config
//  Pode receber string (conteúdo) ou Buffer
// ─────────────────────────────────────────────────────────
function parseManifest(rawContent) {
  const lines  = rawContent.toString('utf8').split(/\r?\n/);
  const parsed = {};

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;

    const eqIdx = trimmed.indexOf('=');
    if (eqIdx === -1) continue;

    const key   = trimmed.slice(0, eqIdx).trim().toUpperCase();
    const value = trimmed.slice(eqIdx + 1).trim();

    if (key in SCHEMA) {
      parsed[key] = value;
    }
  }

  // ── Validação e coerção de tipos ──────────────────────
  const result  = {};
  const errors  = [];

  for (const [key, rules] of Object.entries(SCHEMA)) {
    let value = parsed[key];

    if (value === undefined || value === '') {
      if (rules.required) {
        errors.push(`Campo obrigatório ausente: **${key}**`);
        continue;
      }
      value = rules.default;
    }

    // Coerção
    if (rules.type === 'integer') {
      const n = parseInt(value, 10);
      if (isNaN(n)) {
        errors.push(`${key} deve ser um número inteiro.`);
        continue;
      }
      if (rules.min !== undefined && n < rules.min)
        errors.push(`${key} mínimo é ${rules.min}.`);
      if (rules.max !== undefined && n > rules.max)
        errors.push(`${key} máximo é ${rules.max}.`);
      result[key] = n;

    } else if (rules.type === 'boolean') {
      result[key] = ['true', '1', 'yes', 'sim'].includes(String(value).toLowerCase());

    } else {
      if (rules.maxLen && String(value).length > rules.maxLen)
        errors.push(`${key} muito longo (máx ${rules.maxLen} chars).`);
      result[key] = String(value);
    }
  }

  if (errors.length) {
    throw new Error(`Erros no \`host.config\`:\n${errors.map(e => `• ${e}`).join('\n')}`);
  }

  // ── Valida o MAIN e gera o startCmd ───────────────────
  const ext     = path.extname(result.MAIN).toLowerCase();
  const cmdGen  = MAIN_TO_CMD[ext];

  if (!cmdGen) {
    throw new Error(
      `Extensão \`${ext}\` não suportada no campo MAIN.\n` +
      `Suportadas: ${Object.keys(MAIN_TO_CMD).join(', ')}`
    );
  }

  // Valida que o MAIN não tem path traversal
  if (result.MAIN.includes('..') || path.isAbsolute(result.MAIN)) {
    throw new Error('Campo MAIN não pode conter caminhos absolutos ou `..`');
  }

  result.START_CMD = cmdGen(result.MAIN);

  // Valida nome (mesmas regras do setup)
  if (!/^[a-zA-Z0-9_\- ]+$/.test(result.DISPLAY_NAME)) {
    throw new Error('DISPLAY_NAME deve conter apenas letras, números, espaços, `-` e `_`.');
  }

  logger.info(`[MANIFEST] Parsed OK: ${result.DISPLAY_NAME} | ${result.START_CMD}`);
  return result;
}

// ─────────────────────────────────────────────────────────
//  readManifestFromZip — lê o host.config sem extrair tudo
// ─────────────────────────────────────────────────────────
async function readManifestFromZip(zipPath) {
  const unzipper  = require('unzipper');
  const directory = await unzipper.Open.file(zipPath);

  // Procura host.config na raiz (ou em subpasta de 1 nível)
  const entry = directory.files.find(f =>
    f.path === 'host.config' || f.path.match(/^[^/]+\/host\.config$/)
  );

  if (!entry) {
    throw new Error(
      'Arquivo `host.config` não encontrado na raiz do `.zip`.\n' +
      'Crie o arquivo e tente novamente. Veja o modelo com `/template`.'
    );
  }

  const buffer = await entry.buffer();
  return parseManifest(buffer);
}

// ─────────────────────────────────────────────────────────
//  generateTemplate — gera conteúdo do host.config modelo
// ─────────────────────────────────────────────────────────
function generateTemplate() {
  return [
    '# ============================================',
    '#  host.config — Configuração do Host Bot',
    '#  Coloque este arquivo na RAIZ do seu .zip',
    '# ============================================',
    '',
    '# Nome do seu bot (obrigatório)',
    '# Apenas letras, números, espaços, - e _',
    'DISPLAY_NAME=Meu Bot',
    '',
    '# Arquivo principal (obrigatório)',
    '# Extensões aceitas: .js .mjs .ts .py',
    '# Exemplos:',
    '#   MAIN=index.js',
    '#   MAIN=src/index.js',
    '#   MAIN=bot.py',
    'MAIN=index.js',
    '',
    '# Versão do runtime (opcional)',
    '# "recommended" usa a versão do servidor',
    'VERSION=recommended',
    '',
    '# Limite de memória RAM em MB (opcional)',
    '# Mínimo: 64 | Máximo: 2048 | Padrão: 256',
    'MEMORY=256',
    '',
    '# Reiniciar automaticamente em caso de crash (opcional)',
    '# true = reinicia | false = não reinicia',
    'AUTORESTART=true',
    '',
    '# Descrição do bot (opcional, máx 280 chars)',
    'DESCRIPTION=Descrição do meu bot aqui',
  ].join('\n');
}

module.exports = { readManifestFromZip, parseManifest, generateTemplate };

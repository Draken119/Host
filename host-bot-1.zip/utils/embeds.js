// ============================================================
//  utils/embeds.js — Construtores de Embed reutilizáveis
// ============================================================

const { EmbedBuilder } = require('discord.js');

const COLORS = {
  success: 0x57F287,
  error:   0xED4245,
  warn:    0xFEE75C,
  info:    0x5865F2,
  neutral: 0x2B2D31,
};

function success(title, description) {
  return new EmbedBuilder()
    .setColor(COLORS.success)
    .setTitle(`✅ ${title}`)
    .setDescription(description)
    .setTimestamp();
}

function error(title, description) {
  return new EmbedBuilder()
    .setColor(COLORS.error)
    .setTitle(`❌ ${title}`)
    .setDescription(description)
    .setTimestamp();
}

function warn(title, description) {
  return new EmbedBuilder()
    .setColor(COLORS.warn)
    .setTitle(`⚠️ ${title}`)
    .setDescription(description)
    .setTimestamp();
}

function info(title, description, fields = []) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.info)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
  if (fields.length) embed.addFields(fields);
  return embed;
}

function status(botName, data, stats) {
  const isOnline = stats !== null;
  const color    = isOnline ? COLORS.success : COLORS.error;
  const icon     = isOnline ? '🟢' : '🔴';

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(`${icon} ${botName}`)
    .setTimestamp();

  if (isOnline) {
    embed.addFields(
      { name: '📊 Status',    value: '`Online`',          inline: true },
      { name: '🆔 PID',       value: `\`${stats.pid}\``, inline: true },
      { name: '⏱️ Uptime',   value: `\`${stats.uptime}\``, inline: true },
      { name: '💾 Memória',   value: stats.memoryMB ? `\`${stats.memoryMB} MB\`` : '`N/A`', inline: true },
      { name: '🔁 Restarts', value: `\`${stats.restarts}\``, inline: true },
    );
  } else {
    const dbStatus = data?.status ?? 'stopped';
    embed.addFields(
      { name: '📊 Status', value: `\`${dbStatus}\``, inline: true },
      { name: '🆔 PID',    value: '`—`',             inline: true },
    );
  }

  return embed;
}

module.exports = { success, error, warn, info, status, COLORS };

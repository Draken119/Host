// ============================================================
//  utils/cooldown.js — Sistema de cooldown por usuário/comando
// ============================================================

const config = require('../config');

// Map: `commandName:userId` => timestamp do último uso
const cooldowns = new Map();

/**
 * Verifica e aplica cooldown.
 * @returns {number|null} Milissegundos restantes ou null se pode usar
 */
function checkCooldown(commandName, userId) {
  const key      = `${commandName}:${userId}`;
  const cdMs     = config.COOLDOWNS[commandName] ?? 3_000;
  const lastUsed = cooldowns.get(key);

  if (lastUsed) {
    const remaining = cdMs - (Date.now() - lastUsed);
    if (remaining > 0) return remaining;
  }

  cooldowns.set(key, Date.now());

  // Limpa a entrada após o cooldown expirar (evita memory leak)
  setTimeout(() => cooldowns.delete(key), cdMs + 1_000);

  return null;
}

/**
 * Formata tempo restante em segundos com 1 casa decimal
 */
function formatCooldown(ms) {
  return (ms / 1000).toFixed(1);
}

module.exports = { checkCooldown, formatCooldown };

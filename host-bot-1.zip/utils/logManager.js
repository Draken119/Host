// ============================================================
//  utils/logManager.js — Sistema de logs persistentes
//
//  • Log global do host  → logs/host.log
//  • Log por bot         → bots/{userId}/{botName}/logs/bot.log
//  • Rotação automática  → max 2MB por arquivo, mantém 3 arquivos
//  • Buffer em memória   → últimas 200 linhas por bot (para /logs rápido)
// ============================================================

const fs     = require('fs');
const fsp    = require('fs/promises');
const path   = require('path');
const config = require('../config');

// ── Configurações ─────────────────────────────────────────
const MAX_FILE_SIZE_BYTES = 2 * 1024 * 1024;  // 2MB por arquivo
const MAX_ROTATED_FILES   = 3;                 // host.log.1, .2, .3
const MEMORY_BUFFER_SIZE  = 200;               // linhas em RAM por bot
const HOST_LOG_DIR        = path.join(__dirname, '..', 'logs');
const HOST_LOG_PATH       = path.join(HOST_LOG_DIR, 'host.log');

// ── Map de buffers em memória: botId → string[] ───────────
const memoryBuffers = new Map();

// ── Garante que o diretório de logs do host existe ────────
fs.mkdirSync(HOST_LOG_DIR, { recursive: true });

// ─────────────────────────────────────────────────────────
//  timestamp
// ─────────────────────────────────────────────────────────
function ts() {
  return new Date().toISOString().replace('T', ' ').slice(0, 23);
}

// ─────────────────────────────────────────────────────────
//  rotate — rotaciona o arquivo se passou do limite
// ─────────────────────────────────────────────────────────
function rotateSyncIfNeeded(filePath) {
  try {
    const stat = fs.statSync(filePath);
    if (stat.size < MAX_FILE_SIZE_BYTES) return;

    // Rotaciona: .log.3 → delete, .log.2 → .log.3, etc.
    for (let i = MAX_ROTATED_FILES; i >= 1; i--) {
      const older = `${filePath}.${i}`;
      const newer = i === 1 ? filePath : `${filePath}.${i - 1}`;
      if (fs.existsSync(newer)) {
        if (i === MAX_ROTATED_FILES) {
          fs.unlinkSync(older);
        }
        try { fs.renameSync(newer, older); } catch (_) {}
      }
    }
  } catch (_) {}
}

// ─────────────────────────────────────────────────────────
//  appendToFile — escreve linha no arquivo com rotação
// ─────────────────────────────────────────────────────────
function appendToFile(filePath, line) {
  try {
    // Garante que o diretório existe
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    rotateSyncIfNeeded(filePath);
    fs.appendFileSync(filePath, line + '\n', 'utf8');
  } catch (err) {
    // Nunca deixa o log quebrar a aplicação
    console.error('[LOGMGR] Erro ao escrever log:', err.message);
  }
}

// ─────────────────────────────────────────────────────────
//  getBotLogPath — caminho do log de um bot
// ─────────────────────────────────────────────────────────
function getBotLogPath(folderPath) {
  return path.join(folderPath, 'logs', 'bot.log');
}

// ─────────────────────────────────────────────────────────
//  initBot — inicializa buffer de memória para um bot
// ─────────────────────────────────────────────────────────
function initBot(botId) {
  if (!memoryBuffers.has(botId)) {
    memoryBuffers.set(botId, []);
  }
}

// ─────────────────────────────────────────────────────────
//  writeBotLog — escreve log de stdout/stderr do bot
// ─────────────────────────────────────────────────────────
function writeBotLog(botId, folderPath, rawLine) {
  // Split em múltiplas linhas se necessário
  const lines = rawLine.toString().split(/\r?\n/).filter(l => l.trim());

  for (const line of lines) {
    const formatted = `[${ts()}] ${line}`;

    // 1. Buffer em memória
    if (!memoryBuffers.has(botId)) memoryBuffers.set(botId, []);
    const buf = memoryBuffers.get(botId);
    buf.push(formatted);
    if (buf.length > MEMORY_BUFFER_SIZE) buf.shift();

    // 2. Arquivo do bot
    appendToFile(getBotLogPath(folderPath), formatted);
  }
}

// ─────────────────────────────────────────────────────────
//  writeBotEvent — escreve evento do sistema no log do bot
//  (start, stop, crash, restart, etc.)
// ─────────────────────────────────────────────────────────
function writeBotEvent(botId, folderPath, event) {
  const line = `[${ts()}] [SYSTEM] ${event}`;

  if (!memoryBuffers.has(botId)) memoryBuffers.set(botId, []);
  const buf = memoryBuffers.get(botId);
  buf.push(line);
  if (buf.length > MEMORY_BUFFER_SIZE) buf.shift();

  appendToFile(getBotLogPath(folderPath), line);
  writeHostLog('INFO', event);
}

// ─────────────────────────────────────────────────────────
//  writeHostLog — escreve no log global do host
// ─────────────────────────────────────────────────────────
function writeHostLog(level, message) {
  const line = `[${ts()}] [${level.padEnd(5)}] ${message}`;
  appendToFile(HOST_LOG_PATH, line);
}

// ─────────────────────────────────────────────────────────
//  getMemoryLogs — retorna buffer em memória (rápido)
// ─────────────────────────────────────────────────────────
function getMemoryLogs(botId, lines = 20) {
  const buf = memoryBuffers.get(botId) ?? [];
  return buf.slice(-lines);
}

// ─────────────────────────────────────────────────────────
//  getFileLogs — lê do arquivo (inclui logs de sessões anteriores)
// ─────────────────────────────────────────────────────────
async function getFileLogs(folderPath, lines = 50) {
  const logPath = getBotLogPath(folderPath);
  try {
    const content = await fsp.readFile(logPath, 'utf8');
    const all     = content.split('\n').filter(l => l.trim());
    return all.slice(-lines);
  } catch (_) {
    return [];
  }
}

// ─────────────────────────────────────────────────────────
//  clearBotLogs — limpa logs em memória de um bot
//  (chamado ao deletar)
// ─────────────────────────────────────────────────────────
function clearBotLogs(botId) {
  memoryBuffers.delete(botId);
}

// ─────────────────────────────────────────────────────────
//  getHostLogTail — últimas N linhas do log do host
// ─────────────────────────────────────────────────────────
async function getHostLogTail(lines = 30) {
  try {
    const content = await fsp.readFile(HOST_LOG_PATH, 'utf8');
    const all     = content.split('\n').filter(l => l.trim());
    return all.slice(-lines);
  } catch (_) {
    return [];
  }
}

module.exports = {
  initBot,
  writeBotLog,
  writeBotEvent,
  writeHostLog,
  getMemoryLogs,
  getFileLogs,
  getHostLogTail,
  clearBotLogs,
  getBotLogPath,
  HOST_LOG_PATH,
};

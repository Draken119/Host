// ============================================================
//  config.js — Configurações centrais do Host Bot
// ============================================================

module.exports = {
  // ── Discord ───────────────────────────────────────────────
  TOKEN:     process.env.HOST_TOKEN,
  CLIENT_ID: process.env.CLIENT_ID,
  GUILD_ID:  process.env.GUILD_ID || null,

  // ── Categoria onde os canais de setup são criados ────────
  // Deixe null para criar na raiz do servidor
  SETUP_CATEGORY_ID: process.env.SETUP_CATEGORY_ID || null,

  // ── Limites por usuário ───────────────────────────────────
  MAX_BOTS_PER_USER:   3,
  MAX_ZIP_SIZE_MB:     50,
  MAX_ZIP_SIZE_BYTES:  50 * 1024 * 1024,

  // ── Processo / Recursos ───────────────────────────────────
  NPM_INSTALL_TIMEOUT_MS: 120_000,
  PIP_INSTALL_TIMEOUT_MS: 300_000,
  MAX_LOG_LINES:          20,
  MAX_RESTART_ATTEMPTS:   5,
  RESTART_DELAY_MS:       3_000,

  // ── Docker ────────────────────────────────────────────────
  DOCKER_MEMORY_LIMIT_MB: 256,
  DOCKER_NETWORK:         'hostbot_net',    // rede isolada criada pelo docker-compose

  // ── Timeout do canal de setup (ms) ───────────────────────
  SETUP_TIMEOUT_MS:     120_000,  // 2 min para responder cada etapa
  SETUP_CLOSE_DELAY_MS:  10_000,  // canal fecha 10s após finalizar

  // ── Cooldowns (ms) ───────────────────────────────────────
  COOLDOWNS: {
    up:      60_000,
    commit:  30_000,
    restart:  10_000,
    stop:      5_000,
    delete:   10_000,
    status:    3_000,
    logs:      5_000,
    list:      3_000,
    start:    10_000,
    profile:   5_000,
  },

  // ── Comandos de start permitidos ─────────────────────────
  ALLOWED_START_CMDS: [
    'node', 'npm', 'npx', 'bun',           // JavaScript
    'python3', 'python', 'uvicorn',         // Python (python3 é o principal no container)
    'ts-node', 'tsx', 'deno',
  ],

  // ── Arquivos bloqueados ───────────────────────────────────
  BLOCKED_EXTENSIONS: [
    '.exe', '.bat', '.cmd', '.sh', '.ps1',
    '.msi', '.dll', '.vbs', '.jar',
  ],

  // ── Diretórios ────────────────────────────────────────────
  BOTS_DIR: require('path').join(__dirname, 'bots'),
  DB_PATH:  require('path').join(__dirname, 'database', 'host.json'),
};

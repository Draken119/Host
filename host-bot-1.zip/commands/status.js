// commands/status.js — Mostra status de um bot específico
'use strict';
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { getBotsByUser, getBotById } = require('../database/db');
const pm = require('../processManager');
const embeds = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('📊 Mostra o status de um bot')
    .addIntegerOption(o => o.setName('id').setDescription('ID do bot (opcional)').setRequired(false)),

  async execute(interaction) {
    const userId = interaction.user.id;

    const remaining = checkCooldown('status', userId);
    if (remaining) {
      return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s**.`, ephemeral: true });
    }

    const idOpt = interaction.options.getInteger('id');
    const bots  = getBotsByUser(userId);

    if (bots.length === 0) {
      return interaction.reply({ content: '📭 Você não tem bots hospedados.', ephemeral: true });
    }

    // Se passou ID direto
    if (idOpt !== null) {
      const bot = getBotById(idOpt);
      if (!bot || bot.user_id !== userId) {
        return interaction.reply({ content: '❌ Bot não encontrado.', ephemeral: true });
      }
      const stats = pm.getStats(bot.id);
      return interaction.reply({ embeds: [embeds.status(bot.bot_name, bot, stats)], ephemeral: true });
    }

    // Se só tem 1 bot, mostra direto
    if (bots.length === 1) {
      const bot   = bots[0];
      const stats = pm.getStats(bot.id);
      return interaction.reply({ embeds: [embeds.status(bot.bot_name, bot, stats)], ephemeral: true });
    }

    // Múltiplos bots — select menu
    const select = new StringSelectMenuBuilder()
      .setCustomId('status_select_bot')
      .setPlaceholder('Selecione o bot')
      .addOptions(bots.map(b => {
        const running = pm.isRunning(b.id);
        return { label: `${running ? '🟢' : '🔴'} ${b.bot_name}`, value: String(b.id) };
      }));

    await interaction.reply({
      content: 'Selecione o bot:',
      components: [new ActionRowBuilder().addComponents(select)],
      ephemeral: true,
    });
  },
};

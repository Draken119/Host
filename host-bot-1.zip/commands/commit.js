// commands/commit.js — Atualiza o código de um bot (nova versão)
'use strict';
const { SlashCommandBuilder, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { getBotsByUser, getBotById } = require('../database/db');
const pm = require('../processManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('commit')
    .setDescription('📤 Atualiza o código de um bot com um novo .zip')
    .addIntegerOption(o => o.setName('id').setDescription('ID do bot').setRequired(false)),

  async execute(interaction) {
    const userId = interaction.user.id;
    const remaining = checkCooldown('commit', userId);
    if (remaining) return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s**.`, ephemeral: true });

    const idOpt = interaction.options.getInteger('id');
    const bots  = getBotsByUser(userId);

    if (bots.length === 0) return interaction.reply({ content: '📭 Você não tem bots hospedados.', ephemeral: true });

    const iniciarCommit = async (bot) => {
      const { startCommitSession } = require('../services/setupSession');
      if (typeof startCommitSession === 'function') {
        return startCommitSession(interaction, bot);
      }
      // Fallback: instrução manual
      return interaction.reply({
        content: [
          `📤 **Atualização de ${bot.bot_name}**`,
          '',
          'Para atualizar, use `/delete` para remover a versão atual e `/up` para fazer upload da nova versão.',
          '',
          '> ⚠️ Isso irá remover os arquivos atuais. Faça backup se necessário.',
        ].join('\n'),
        ephemeral: true,
      });
    };

    if (idOpt !== null) {
      const bot = getBotById(idOpt);
      if (!bot || bot.user_id !== userId) return interaction.reply({ content: '❌ Bot não encontrado.', ephemeral: true });
      return iniciarCommit(bot);
    }

    if (bots.length === 1) return iniciarCommit(bots[0]);

    const select = new StringSelectMenuBuilder()
      .setCustomId('commit_select_bot')
      .setPlaceholder('Selecione o bot para atualizar')
      .addOptions(bots.map(b => {
        const icon = pm.isRunning(b.id) ? '🟢' : '🔴';
        return { label: `${icon} ${b.bot_name}`, value: String(b.id) };
      }));

    await interaction.reply({ content: 'Selecione o bot:', components: [new ActionRowBuilder().addComponents(select)], ephemeral: true });
  },
};

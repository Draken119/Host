// commands/restart.js — Reinicia um bot
'use strict';
const { SlashCommandBuilder, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { getBotsByUser, getBotById } = require('../database/db');
const pm = require('../processManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('restart')
    .setDescription('🔄 Reinicia um bot')
    .addIntegerOption(o => o.setName('id').setDescription('ID do bot').setRequired(false)),

  async execute(interaction) {
    const userId = interaction.user.id;
    const remaining = checkCooldown('restart', userId);
    if (remaining) return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s**.`, ephemeral: true });

    const idOpt = interaction.options.getInteger('id');
    const bots  = getBotsByUser(userId);

    if (bots.length === 0) return interaction.reply({ content: '📭 Você não tem bots hospedados.', ephemeral: true });

    const doRestart = async (bot) => {
      await interaction.deferReply({ ephemeral: true });
      if (pm.isRunning(bot.id)) await pm.killProcess(bot.id);
      await new Promise(r => setTimeout(r, 1500));
      await pm.startProcess(bot.id, bot.folder_path, bot.start_cmd, true, bot.memory);
      return interaction.editReply({ content: `🔄 **${bot.bot_name}** reiniciado com sucesso!` });
    };

    if (idOpt !== null) {
      const bot = getBotById(idOpt);
      if (!bot || bot.user_id !== userId) return interaction.reply({ content: '❌ Bot não encontrado.', ephemeral: true });
      return doRestart(bot);
    }

    if (bots.length === 1) return doRestart(bots[0]);

    const select = new StringSelectMenuBuilder()
      .setCustomId('restart_select_bot')
      .setPlaceholder('Selecione o bot para reiniciar')
      .addOptions(bots.map(b => {
        const icon = pm.isRunning(b.id) ? '🟢' : '🔴';
        return { label: `${icon} ${b.bot_name}`, value: String(b.id) };
      }));

    await interaction.reply({ content: 'Selecione o bot:', components: [new ActionRowBuilder().addComponents(select)], ephemeral: true });
  },
};

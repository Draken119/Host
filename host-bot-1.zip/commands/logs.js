// commands/logs.js — Mostra logs de um bot
'use strict';
const { SlashCommandBuilder, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { getBotsByUser, getBotById } = require('../database/db');
const lm = require('../utils/logManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('logs')
    .setDescription('📄 Mostra os últimos logs de um bot')
    .addIntegerOption(o => o.setName('id').setDescription('ID do bot').setRequired(false))
    .addIntegerOption(o => o.setName('linhas').setDescription('Quantidade de linhas (padrão: 20)').setRequired(false)),

  async execute(interaction) {
    const userId = interaction.user.id;
    const remaining = checkCooldown('logs', userId);
    if (remaining) return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s**.`, ephemeral: true });

    const idOpt     = interaction.options.getInteger('id');
    const linhas    = Math.min(interaction.options.getInteger('linhas') ?? 20, 50);
    const bots      = getBotsByUser(userId);

    if (bots.length === 0) return interaction.reply({ content: '📭 Você não tem bots hospedados.', ephemeral: true });

    const enviarLogs = async (bot) => {
      await interaction.deferReply({ ephemeral: true });
      const lines = lm.getMemoryLogs(bot.id, linhas);
      if (lines.length === 0) {
        return interaction.editReply({ content: `📄 Nenhum log disponível para **${bot.bot_name}** ainda.` });
      }
      const texto = lines.join('\n');
      if (texto.length > 1900) {
        const buf = Buffer.from(texto, 'utf-8');
        return interaction.editReply({
          content: `📄 Últimas ${lines.length} linhas de **${bot.bot_name}**:`,
          files: [{ attachment: buf, name: `${bot.bot_name}_logs.txt` }],
        });
      }
      return interaction.editReply({ content: `📄 **${bot.bot_name}** — últimas ${lines.length} linhas:\n\`\`\`\n${texto}\n\`\`\`` });
    };

    if (idOpt !== null) {
      const bot = getBotById(idOpt);
      if (!bot || bot.user_id !== userId) return interaction.reply({ content: '❌ Bot não encontrado.', ephemeral: true });
      return enviarLogs(bot);
    }

    if (bots.length === 1) return enviarLogs(bots[0]);

    const select = new StringSelectMenuBuilder()
      .setCustomId('logs_select_bot')
      .setPlaceholder('Selecione o bot')
      .addOptions(bots.map(b => ({ label: b.bot_name, value: String(b.id) })));

    await interaction.reply({ content: 'Selecione o bot:', components: [new ActionRowBuilder().addComponents(select)], ephemeral: true });
  },
};

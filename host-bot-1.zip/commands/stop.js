// commands/stop.js — Para um bot em execução
'use strict';
const { SlashCommandBuilder, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { getBotsByUser, getBotById } = require('../database/db');
const pm = require('../processManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stop')
    .setDescription('⏹️ Para um bot em execução')
    .addIntegerOption(o => o.setName('id').setDescription('ID do bot').setRequired(false)),

  async execute(interaction) {
    const userId = interaction.user.id;
    const remaining = checkCooldown('stop', userId);
    if (remaining) return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s**.`, ephemeral: true });

    const idOpt   = interaction.options.getInteger('id');
    const running = getBotsByUser(userId).filter(b => pm.isRunning(b.id));

    if (running.length === 0) return interaction.reply({ content: '⏹️ Nenhum dos seus bots está em execução.', ephemeral: true });

    if (idOpt !== null) {
      const bot = getBotById(idOpt);
      if (!bot || bot.user_id !== userId) return interaction.reply({ content: '❌ Bot não encontrado.', ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      await pm.killProcess(bot.id);
      return interaction.editReply({ content: `⏹️ **${bot.bot_name}** parado.` });
    }

    if (running.length === 1) {
      await interaction.deferReply({ ephemeral: true });
      const bot = running[0];
      await pm.killProcess(bot.id);
      return interaction.editReply({ content: `⏹️ **${bot.bot_name}** parado.` });
    }

    const select = new StringSelectMenuBuilder()
      .setCustomId('stop_select_bot')
      .setPlaceholder('Selecione o bot para parar')
      .addOptions(running.map(b => ({ label: `🟢 ${b.bot_name}`, value: String(b.id) })));

    await interaction.reply({ content: 'Selecione o bot:', components: [new ActionRowBuilder().addComponents(select)], ephemeral: true });
  },
};

// commands/up.js — Hospeda um novo bot
'use strict';
const { SlashCommandBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { startSession } = require('../services/setupSession');
const { isBanned }     = require('../database/users');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('up')
    .setDescription('🚀 Hospeda um novo bot enviando o arquivo .zip'),

  async execute(interaction) {
    const { id: userId } = interaction.user;

    const ban = await isBanned(userId);
    if (ban.banned) {
      return interaction.reply({ content: `🚫 Você está banido.\n**Motivo:** ${ban.reason}`, ephemeral: true });
    }

    const remaining = checkCooldown('up', userId);
    if (remaining) {
      return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s** para usar /up novamente.`, ephemeral: true });
    }

    await startSession(interaction);
  },
};

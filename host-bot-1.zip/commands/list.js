// commands/list.js — Lista todos os bots do usuário
'use strict';
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { getBotsByUser } = require('../database/db');
const pm = require('../processManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('list')
    .setDescription('📋 Lista todos os seus bots hospedados'),

  async execute(interaction) {
    const userId = interaction.user.id;

    const remaining = checkCooldown('list', userId);
    if (remaining) {
      return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s**.`, ephemeral: true });
    }

    const bots = getBotsByUser(userId);

    if (bots.length === 0) {
      return interaction.reply({
        content: '📭 Você não tem nenhum bot hospedado.\nUse `/up` para hospedar seu primeiro bot!',
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setTitle('🤖 Seus Bots Hospedados')
      .setColor(0x5865F2)
      .setTimestamp()
      .setFooter({ text: `Total: ${bots.length} bot(s)` });

    for (const bot of bots) {
      const running = pm.isRunning(bot.id);
      const stats   = pm.getStats(bot.id);
      const icon    = running ? '🟢' : '🔴';
      const uptime  = stats ? stats.uptime : '—';

      embed.addFields({
        name:   `${icon} ${bot.bot_name}`,
        value:  `ID: \`${bot.id}\` | Status: \`${running ? 'Online' : bot.status}\`${running ? ` | Uptime: \`${uptime}\`` : ''}`,
        inline: false,
      });
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

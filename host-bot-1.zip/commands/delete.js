// commands/delete.js — Deleta um bot completamente
'use strict';
const { SlashCommandBuilder, StringSelectMenuBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { getBotsByUser, getBotById, deleteBot } = require('../database/db');
const pm = require('../processManager');
const bm = require('../botManager');
const lm = require('../utils/logManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('delete')
    .setDescription('🗑️ Deleta um bot e todos os seus arquivos')
    .addIntegerOption(o => o.setName('id').setDescription('ID do bot').setRequired(false)),

  async execute(interaction) {
    const userId = interaction.user.id;
    const remaining = checkCooldown('delete', userId);
    if (remaining) return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s**.`, ephemeral: true });

    const idOpt = interaction.options.getInteger('id');
    const bots  = getBotsByUser(userId);

    if (bots.length === 0) return interaction.reply({ content: '📭 Você não tem bots para deletar.', ephemeral: true });

    const confirmar = async (bot) => {
      const embed = new EmbedBuilder()
        .setTitle('⚠️ Confirmar exclusão')
        .setDescription(`Tem certeza que deseja deletar **${bot.bot_name}**?\n\n> ⚠️ Todos os arquivos serão removidos permanentemente.`)
        .setColor(0xED4245);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`del_confirm_${bot.id}`).setLabel('Sim, deletar').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('del_cancel').setLabel('Cancelar').setStyle(ButtonStyle.Secondary),
      );

      await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    };

    if (idOpt !== null) {
      const bot = getBotById(idOpt);
      if (!bot || bot.user_id !== userId) return interaction.reply({ content: '❌ Bot não encontrado.', ephemeral: true });
      return confirmar(bot);
    }

    if (bots.length === 1) return confirmar(bots[0]);

    const select = new StringSelectMenuBuilder()
      .setCustomId('delete_select_bot')
      .setPlaceholder('Selecione o bot para deletar')
      .addOptions(bots.map(b => ({ label: b.bot_name, value: String(b.id) })));

    await interaction.reply({ content: 'Selecione o bot:', components: [new ActionRowBuilder().addComponents(select)], ephemeral: true });
  },
};

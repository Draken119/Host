// commands/start.js — Inicia um bot parado
'use strict';
const { SlashCommandBuilder, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { getBotsByUser, getBotById, updateBot } = require('../database/db');
const pm = require('../processManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('start')
    .setDescription('▶️ Inicia um bot parado')
    .addIntegerOption(o => o.setName('id').setDescription('ID do bot').setRequired(false)),

  async execute(interaction) {
    const userId = interaction.user.id;
    const remaining = checkCooldown('start', userId);
    if (remaining) return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s**.`, ephemeral: true });

    const idOpt = interaction.options.getInteger('id');
    const bots  = getBotsByUser(userId).filter(b => !pm.isRunning(b.id));

    if (bots.length === 0) return interaction.reply({ content: '✅ Todos os seus bots já estão online!', ephemeral: true });

    if (idOpt !== null) {
      const bot = getBotById(idOpt);
      if (!bot || bot.user_id !== userId) return interaction.reply({ content: '❌ Bot não encontrado.', ephemeral: true });
      if (pm.isRunning(bot.id)) return interaction.reply({ content: '✅ Bot já está online!', ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      await pm.startProcess(bot.id, bot.folder_path, bot.start_cmd, true, bot.memory);
      return interaction.editReply({ content: `✅ **${bot.bot_name}** iniciado!` });
    }

    if (bots.length === 1) {
      await interaction.deferReply({ ephemeral: true });
      const bot = bots[0];
      await pm.startProcess(bot.id, bot.folder_path, bot.start_cmd, true, bot.memory);
      return interaction.editReply({ content: `✅ **${bot.bot_name}** iniciado!` });
    }

    const select = new StringSelectMenuBuilder()
      .setCustomId('start_select_bot')
      .setPlaceholder('Selecione o bot para iniciar')
      .addOptions(bots.map(b => ({ label: `🔴 ${b.bot_name}`, value: String(b.id) })));

    await interaction.reply({ content: 'Selecione o bot:', components: [new ActionRowBuilder().addComponents(select)], ephemeral: true });
  },
};

// commands/profile.js — Perfil do usuário na host
'use strict';
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { checkCooldown, formatCooldown } = require('../utils/cooldown');
const { getUser, upsertUser } = require('../database/users');
const { getBotsByUser } = require('../database/db');
const pm = require('../processManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('👤 Mostra seu perfil na host'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const remaining = checkCooldown('profile', userId);
    if (remaining) return interaction.reply({ content: `⏳ Aguarde **${formatCooldown(remaining)}s**.`, ephemeral: true });

    await interaction.deferReply({ ephemeral: true });

    const user = await upsertUser(interaction.user);
    const bots = getBotsByUser(userId);
    const online = bots.filter(b => pm.isRunning(b.id)).length;

    const embed = new EmbedBuilder()
      .setTitle(`👤 ${user.display_name}`)
      .setColor(0x5865F2)
      .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '🤖 Bots Ativos',       value: `**${online}**/${bots.length}`,    inline: true },
        { name: '📦 Total Hospedados',   value: `**${user.bots_hosted}**`,          inline: true },
        { name: '📅 Membro Desde',       value: user.joined_at
            ? `<t:${Math.floor(new Date(user.joined_at).getTime() / 1000)}:D>`
            : '—', inline: true },
        { name: '🕐 Última Atividade',   value: user.last_seen
            ? `<t:${Math.floor(new Date(user.last_seen).getTime() / 1000)}:R>`
            : '—', inline: true },
        { name: '🚫 Banido',             value: user.is_banned ? `Sim — ${user.ban_reason}` : 'Não', inline: true },
      )
      .setTimestamp();

    if (bots.length > 0) {
      const botsTexto = bots.map(b => {
        const icon = pm.isRunning(b.id) ? '🟢' : '🔴';
        return `${icon} **${b.bot_name}** (ID: \`${b.id}\`)`;
      }).join('\n');
      embed.addFields({ name: '🤖 Seus Bots', value: botsTexto, inline: false });
    }

    await interaction.editReply({ embeds: [embed] });
  },
};
